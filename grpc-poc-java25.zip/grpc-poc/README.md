# Java 25 / Spring Boot 4.1 gRPC POC

## Run
Install JDK 25 and Maven 3.9+, then from this directory run `mvn clean package`.
In terminal 1: `java -jar grpc-server/target/grpc-server-1.0.0.jar`
In terminal 2: `java -jar grpc-client/target/grpc-client-1.0.0.jar`

## Verify (expected results, not executed in authoring environment)
- `curl -i http://localhost:8080/api/accounts/A100` -> 200, account A100, balanceMinor 125050.
- `curl -i http://localhost:8080/api/accounts/A100/async` -> same data, async stub.
- `curl -i http://localhost:8080/api/accounts` -> both accounts via server streaming, aggregated into JSON.
- `curl -i http://localhost:8080/api/accounts/UNKNOWN` -> 404, grpcStatus NOT_FOUND.
- Stop server, repeat first request -> normally 503 UNAVAILABLE or 504 if deadline expires.
- Optional grpcurl: `grpcurl -plaintext localhost:9090 list` and `grpcurl -plaintext -d '{"accountId":"A100"}' localhost:9090 account.v1.AccountService/GetAccount`.

## How it works
1. Maven generates protobuf message classes and AccountServiceGrpc from the contract. Never edit generated code.
2. Server registers the generated base implementation as a Spring bean; Netty listens on 9090.
3. @ImportGrpcClients registers blocking and async stub beans for logical channel accounts. Spring manages channel lifecycle. Change ACCOUNT_GRPC_TARGET to connect to a compatible remote server.
4. REST controller invokes the client service. The stub marshals protobuf, sends an HTTP/2 RPC, and unmarshals the reply. REST DTOs keep generated types out of the public JSON API.
5. Blocking calls occupy the caller thread; async uses callbacks and completes a future after the terminal callback. The deadline is applied independently to every RPC. The server streaming example collects a tiny finite result; it is not a production streaming HTTP bridge.
6. gRPC status codes are translated to HTTP responses without leaking downstream exception details.

## Production considerations
Plaintext is only for local development; do not expose port 9090 to untrusted networks. Configure TLS/mTLS, authentication and authorization, bounded concurrency, observability and appropriate deadlines. Retry only safe/idempotent calls with bounded backoff. Reuse channels/stubs, do not create them per request. For large streams use flow control and cancellation propagation. The CompletableFuture example does not propagate HTTP disconnect/cancellation to the gRPC call; the deadline bounds it. No database, real account data, or production credentials are included.

Reference: https://docs.spring.io/spring-boot/4.1/reference/io/grpc.html

Build validation limitation: source authored against the official APIs; the authoring environment has Java 21 and no Maven, so compilation/runtime tests were not executed.
