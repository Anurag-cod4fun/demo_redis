package com.example.grpc.server;
import com.example.grpc.contract.*;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;
import io.grpc.Context;
import org.springframework.grpc.server.service.GrpcService;
@GrpcService
public class AccountGrpcService extends AccountServiceGrpc.AccountServiceImplBase {
    private final AccountRepository repository;
    public AccountGrpcService(AccountRepository repository) { this.repository = repository; }
    @Override
    public void getAccount(AccountRequest request, StreamObserver<AccountReply> observer) {
        if (request.getAccountId().isBlank()) {
            observer.onError(Status.INVALID_ARGUMENT.withDescription("Account ID is required").asRuntimeException());
            return;
        }
        var account = repository.find(request.getAccountId());
        if (account.isEmpty()) {
            observer.onError(Status.NOT_FOUND.withDescription("Account not found").asRuntimeException());
            return;
        }
        observer.onNext(account.get()); // Send one response.
        observer.onCompleted(); // Terminate successfully.
    }
    @Override
    public void listAccounts(ListAccountsRequest request, StreamObserver<AccountReply> observer) {
        for (var account : repository.all()) {
            if (Context.current().isCancelled()) return;
            observer.onNext(account);
        }
        observer.onCompleted();
    }
}
