package com.example.grpc.server;
import com.example.grpc.contract.AccountReply;
import org.springframework.stereotype.Repository;
import java.util.*;
@Repository
public class AccountRepository {
    private final List<AccountReply> accounts = List.of(account("A100", "Demo Customer", 125050), account("A200", "Sample Customer", 95000));
    private static AccountReply account(String id, String holder, long balance) {
        return AccountReply.newBuilder().setAccountId(id).setHolder(holder).setBalanceMinor(balance).setCurrency("INR").build();
    }
    public Optional<AccountReply> find(String id) { return accounts.stream().filter(a -> a.getAccountId().equals(id)).findFirst(); }
    public List<AccountReply> all() { return accounts; }
}
