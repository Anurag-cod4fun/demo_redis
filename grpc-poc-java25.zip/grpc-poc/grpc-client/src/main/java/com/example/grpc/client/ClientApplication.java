package com.example.grpc.client;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.grpc.client.ImportGrpcClients;
import com.example.grpc.contract.AccountServiceGrpc;

@SpringBootApplication(proxyBeanMethods = false)
@ImportGrpcClients(target = "accounts", types = {AccountServiceGrpc.AccountServiceBlockingStub.class, AccountServiceGrpc.AccountServiceStub.class})
public class ClientApplication {
    public static void main(String[] args) { SpringApplication.run(ClientApplication.class, args); }
}
