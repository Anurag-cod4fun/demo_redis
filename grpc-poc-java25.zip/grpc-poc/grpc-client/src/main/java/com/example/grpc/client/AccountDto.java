package com.example.grpc.client;
import com.example.grpc.contract.AccountReply;
public record AccountDto(String accountId, String holder, long balanceMinor, String currency) {
    static AccountDto from(AccountReply reply) {
        return new AccountDto(reply.getAccountId(), reply.getHolder(), reply.getBalanceMinor(), reply.getCurrency());
    }
}
