package com.example.grpc.client;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.concurrent.CompletableFuture;
@RestController
@RequestMapping("/api/accounts")
public class AccountController {
    private final AccountGrpcClient client;
    public AccountController(AccountGrpcClient client) { this.client = client; }
    @GetMapping("/{id}") public AccountDto get(@PathVariable String id) { return client.getAccount(id); }
    @GetMapping("/{id}/async") public CompletableFuture<AccountDto> async(@PathVariable String id) { return client.getAccountAsync(id); }
    @GetMapping public List<AccountDto> list() { return client.listAccounts(); }
}
