package com.example.grpc.client;
import io.grpc.StatusRuntimeException;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@RestControllerAdvice
public class GrpcExceptionHandler {
    @ExceptionHandler(StatusRuntimeException.class)
    public ResponseEntity<ProblemDetail> handle(StatusRuntimeException ex) {
        HttpStatus status = switch (ex.getStatus().getCode()) {
            case NOT_FOUND -> HttpStatus.NOT_FOUND;
            case INVALID_ARGUMENT -> HttpStatus.BAD_REQUEST;
            case DEADLINE_EXCEEDED -> HttpStatus.GATEWAY_TIMEOUT;
            case UNAVAILABLE -> HttpStatus.SERVICE_UNAVAILABLE;
            case PERMISSION_DENIED -> HttpStatus.FORBIDDEN;
            case UNAUTHENTICATED -> HttpStatus.UNAUTHORIZED;
            default -> HttpStatus.BAD_GATEWAY;
        };
        var detail = ProblemDetail.forStatusAndDetail(status, "Account service call failed");
        detail.setProperty("grpcStatus", ex.getStatus().getCode().name());
        return ResponseEntity.status(status).body(detail);
    }
}
