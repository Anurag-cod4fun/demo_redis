package com.example.grpc.client;
import com.example.grpc.contract.*;
import io.grpc.stub.StreamObserver;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.concurrent.*;
@Service
public class AccountGrpcClient {
    private final AccountServiceGrpc.AccountServiceBlockingStub blockingStub;
    private final AccountServiceGrpc.AccountServiceStub asyncStub;
    private final long deadlineMs;
    public AccountGrpcClient(AccountServiceGrpc.AccountServiceBlockingStub blockingStub,
            AccountServiceGrpc.AccountServiceStub asyncStub, @Value("${app.grpc.deadline-ms:2000}") long deadlineMs) {
        if (deadlineMs <= 0) throw new IllegalArgumentException("Deadline must be positive");
        this.blockingStub = blockingStub;
        this.asyncStub = asyncStub;
        this.deadlineMs = deadlineMs;
    }
    public AccountDto getAccount(String id) {
        // Stubs are reusable and immutable: withDeadlineAfter returns a derived stub per call.
        return AccountDto.from(blockingStub.withDeadlineAfter(deadlineMs, TimeUnit.MILLISECONDS)
                .getAccount(AccountRequest.newBuilder().setAccountId(id).build()));
    }
    public CompletableFuture<AccountDto> getAccountAsync(String id) {
        var result = new CompletableFuture<AccountDto>();
        asyncStub.withDeadlineAfter(deadlineMs, TimeUnit.MILLISECONDS).getAccount(
                AccountRequest.newBuilder().setAccountId(id).build(), new StreamObserver<AccountReply>() {
            private AccountReply reply;
            public void onNext(AccountReply value) { reply = value; }
            public void onError(Throwable error) { result.completeExceptionally(error); }
            public void onCompleted() {
                if (reply == null) result.completeExceptionally(new IllegalStateException("Missing unary response"));
                else result.complete(AccountDto.from(reply));
            }
        });
        return result;
    }
    public List<AccountDto> listAccounts() {
        var iterator = blockingStub.withDeadlineAfter(deadlineMs, TimeUnit.MILLISECONDS)
                .listAccounts(ListAccountsRequest.getDefaultInstance());
        var result = new ArrayList<AccountDto>();
        iterator.forEachRemaining(reply -> result.add(AccountDto.from(reply)));
        return List.copyOf(result);
    }
}
