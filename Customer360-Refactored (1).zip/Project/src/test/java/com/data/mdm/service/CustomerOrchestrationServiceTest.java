package com.data.mdm.service;

import com.data.mdm.dto.*;
import com.data.mdm.validation.CustomerRequestValidator;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CustomerOrchestrationServiceTest {
    private final CustomerService customer = mock(CustomerService.class);
    private final ProcessAccountService account = mock(ProcessAccountService.class);
    private final ProcessAncillaryService ancillary = mock(ProcessAncillaryService.class);
    private final CustomerRequestValidator validator = mock(CustomerRequestValidator.class);
    private final CustomerOrchestrationService service = new CustomerOrchestrationService(
            customer, account, ancillary, validator, Runnable::run);

    private CustomerRequest request(Customer c, Account a, Ancillary n) {
        return new CustomerRequest(new CustomerRequest.Head("2026-11-26", "trace-1", "I"),
                new CustomerRequest.RequestBody(a, c, n));
    }

    @Test void collectsAllResults() {
        var request = request(new Customer(), new Account(), new Ancillary());
        when(customer.process(request)).thenReturn(ServiceResult.success("customer"));
        when(account.process(request)).thenReturn(ServiceResult.success("account"));
        when(ancillary.process(request)).thenReturn(ServiceResult.success("ancillary"));
        var result = service.process(request).join();
        assertEquals("customer", result.customer().message());
        assertEquals("account", result.account().message());
        assertEquals("ancillary", result.ancillary().message());
    }

    @Test void isolatesFailureAndSkipsMissingSection() {
        var request = request(new Customer(), new Account(), null);
        when(customer.process(request)).thenThrow(new IllegalStateException("internal"));
        when(account.process(request)).thenReturn(ServiceResult.success("account"));
        var result = service.process(request).join();
        assertEquals(ServiceResult.Status.FAILED, result.customer().status());
        assertEquals(ServiceResult.Status.SUCCESS, result.account().status());
        assertEquals(ServiceResult.Status.SKIPPED, result.ancillary().status());
        verifyNoInteractions(ancillary);
    }
}
