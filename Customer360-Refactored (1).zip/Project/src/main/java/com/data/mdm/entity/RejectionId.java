package com.data.mdm.entity;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.SequenceGenerator;

@Embeddable
public class RejectionId implements Serializable {

    @Column(name = "SOURCESYSTEMCODE", nullable = false, length = 50)
    private String sourceSystemCode;

    @Column(name = "SOURCEPARTID", nullable = false, length = 100)
    private String sourcePartyId;

    @Column(name = "SOURCETIMESTAMP", nullable = false)
    private LocalDateTime sourceTimestamp;

    
    @Column(name = "SEQUENCENUMBER", nullable = false)
    private Long sequenceNumber;

    // Default constructor required by JPA
    public RejectionId() {
    }

    public RejectionId(String sourceSystemCode, String sourcePartyId, LocalDateTime sourceTimestamp, Long sequenceNumber) {
        this.sourceSystemCode = sourceSystemCode;
        this.sourcePartyId = sourcePartyId;
        this.sourceTimestamp = sourceTimestamp;
        this.sequenceNumber = sequenceNumber;
    }

    // Getters and Setters
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public String getSourcePartyId() {
        return sourcePartyId;
    }

    public void setSourcePartyId(String sourcePartyId) {
        this.sourcePartyId = sourcePartyId;
    }

    public LocalDateTime getSourceTimestamp() {
        return sourceTimestamp;
    }

    public void setSourceTimestamp(LocalDateTime sourceTimestamp) {
        this.sourceTimestamp = sourceTimestamp;
    }

    public Long getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(Long sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

      @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RejectionId that = (RejectionId) o;
        return Objects.equals(sourceSystemCode, that.sourceSystemCode) &&
               Objects.equals(sourcePartyId, that.sourcePartyId) &&
               Objects.equals(sourceTimestamp, that.sourceTimestamp) &&
               Objects.equals(sequenceNumber, that.sequenceNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sourceSystemCode, sourcePartyId, sourceTimestamp, sequenceNumber);
    }
}