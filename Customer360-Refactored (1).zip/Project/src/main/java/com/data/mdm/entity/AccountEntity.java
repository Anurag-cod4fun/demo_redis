package com.data.mdm.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "MDM_ACCOUNT_MASTER")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountEntity {

    @Id
    @Column(name = "SOURCE_ACCOUNT_NUMBER", length = 50, nullable = false)
    private String sourceAccountNumber;

    @Column(name = "SOURCE_PARTY_ID", length = 50)
    private String sourcePartyId;

    @Column(name = "SOURCE_SYSTEM_CODE", length = 20)
    private String sourceSystemCode;

    @Column(name = "DEL_FLAG", length = 1)
    private String delFlag;

    @Column(name = "ACCOUNT_OPEN_DATE")
    private String accountOpenDate;

    @Column(name = "ACCOUNT_CLOSE_DATE")
    private String accountCloseDate;

    @Column(name = "ACCOUNT_STATUS", length = 20)
    private String accountStatus;

    @Column(name = "CLOSED_FLAG", length = 1)
    private String closedFlag;

    @Column(name = "SCHEME_CODE", length = 20)
    private String schemeCode;

    @Column(name = "SCHEME_TYPE", length = 20)
    private String schemeType;

    @Column(name = "ACC_HOLDER", length = 100)
    private String accHolder;

    @Column(name = "ACCOUNT_TYPE", length = 30)
    private String accountType;

    @Column(name = "PRODUCT_ID", length = 30)
    private String productId;

    @Column(name = "PRODUCT_TYPE", length = 30)
    private String productType;

    @Column(name = "RELATION_WITH_PRIMARY", length = 30)
    private String relationWithPrimary;

    @Column(name = "FORECLOSE_BLOCK_CODE", length = 20)
    private String forecloseBlockCode;

    @Column(name = "LIEN_REASON_CODE", length = 20)
    private String lienReasonCode;

    @Column(name = "SOURCE_OF_INCOME", length = 50)
    private String sourceOfIncome;

    @Column(name = "SOURCE_OF_FUNDS", length = 50)
    private String sourceOfFunds;

    @Column(name = "FREZ_REASON_CODE", length = 20)
    private String frezReasonCode;

    @Column(name = "FREZ_REASON_CODE_2", length = 20)
    private String frezReasonCode2;

    @Column(name = "FREZ_REASON_CODE_3", length = 20)
    private String frezReasonCode3;

    @Column(name = "FREZ_REASON_CODE_4", length = 20)
    private String frezReasonCode4;

    @Column(name = "FREZ_REASON_CODE_5", length = 20)
    private String frezReasonCode5;

    @Column(name = "FREEZE_CODE_FLAG", length = 1)
    private String freezeCodeFlag;

    @Column(name = "FREEZ_UNFREEZ_FLAG", length = 1)
    private String freezUnfreezFlag;

    @Column(name = "F_NOMINEE", length = 1)
    private String fNominee;

    @Column(name = "NRI_STATUS", length = 10)
    private String nriStatus;

    @Column(name = "SRC_CREATED_ON")
    private String srcCreatedOn;

    @Column(name = "SRC_MODIFIED_ON")
    private String srcModifiedOn;

    @Column(name = "DATE_CREATED")
    private String dateCreated;

    @Column(name = "DATE_LAST_MODIFIED")
    private String dateLastModified;
}