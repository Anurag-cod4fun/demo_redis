package com.data.mdm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.data.mdm.entity.AuditId;
import com.data.mdm.entity.AuditLog;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, AuditId> {
}

