package com.data.mdm.ms;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
 
@Data
public class TransactionStatus {
 
	@JsonProperty("Status")
    private String status;
	
	@JsonProperty("UCIC")
	private String ucic;
	
	@JsonProperty("Description")
    private String description;
	
	@JsonProperty("Reason")
    private String reason;
}
 