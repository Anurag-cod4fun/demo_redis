//package com.data.mdm.client;
//
//import com.fasterxml.jackson.annotation.JsonProperty;
//
//public class TransactionalStatus {
//	@JsonProperty("Status")
//    private String status;
//
//    @JsonProperty("Description")
//    private String description;
//
//    @JsonProperty("Reason")
//    private String reason;
//
//    @JsonProperty("ucic")
//    private String ucic;
//
//	
//	public String getStatus() {
//		return status;
//	}
//
//	public void setStatus(String status) {
//		this.status = status;
//	}
//
//	public String getDescription() {
//		return description;
//	}
//
//	public void setDescription(String description) {
//		this.description = description;
//	}
//
//	public String getUcic() {
//		return ucic;
//	}
//
//	public void setUcic(String ucic) {
//		this.ucic = ucic;
//	}
//
//	public String getReason() {
//		return reason;
//	}
//
//	public void setReason(String reason) {
//		this.reason = reason;
//	}
//}
