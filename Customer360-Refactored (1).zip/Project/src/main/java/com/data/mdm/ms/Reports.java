package com.data.mdm.ms;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
 
@Data
public class Reports {
 
	@JsonProperty("Report")
    private Report report;
}
 