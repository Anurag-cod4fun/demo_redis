package com.data.mdm.stub;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.json.JsonMapper;

@org.springframework.context.annotation.Profile("local")
@RestController
public class StubController {

	@PostMapping("/getResp")
	public ResponseEntity<JsonNode> getResponse() throws JsonMappingException, JsonProcessingException {

		String bodyString = """
								{
				  "Root": {
				    "Output": {
				      "Record": {
				        "STATUS": "ACTIVE",
				        "SEGMENT": "PREMIUM",
				        "CREATED_AT": "22-03-1998",
				        "DOB": "22-03-1998",
				        "PHONE": "9123456789",
				        "CUSTOMER_ID": "FHFGHGVGVFT8766",
				        "GENDER": "F",
				        "LAST_NAME": "SHARMA",
				        "PAN": "PQR000079K",
				        "EMAIL": "PRIYA.SHARMA@EXAMPLE.COM",
				        "RISK_RATING": "LOW",
				        "FIRST_NAME": "PRIYA"
				      }
				    }
				  },
				  "Transaction Status": {
				    "Status": "Success",
				    "UCIC": "9320932",
				    "Description": "Insert successful!",
				    "Reason": ""
				  },
				  "Processing_Exceptions": {
				    "Reject": "",
				    "Reports": {
				      "Report":{
				      "Field_Value": "PRIYA.SHARMA@EXAMPLE.COM",
				      "Field_Name": "email",
				      "Reason": "EMAIL_LENGTH_IS_MORE_THAN_MAX_LENGTH 15"
				      }
				    }
				  }
				}

				""";
		return ResponseEntity.ok(new JsonMapper().readTree(bodyString));
	}
}
//package com.data.mdm.stub;
//
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.JsonMappingException;
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.json.JsonMapper;
//
//@RestController
//public class StubController {
//
//	@PostMapping("/getResp")
//	public ResponseEntity<JsonNode> getResponse() throws JsonMappingException, JsonProcessingException{
//		String  bodyString = """
//				{
//			        "Output": "Aviskhar",
//			        "TransactionStatus": {
//			            "Status": "Success",
//			            "Description": "",
//			            "Reason": "",
//			            "ucic":"AVI"
//			    	}
//				}
//				""";
//		return ResponseEntity.ok(new JsonMapper().readTree(bodyString));
//	}
//}
//
//
//
//
