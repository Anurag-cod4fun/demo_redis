package com.data.mdm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MwRequestBody {
	

	public MwRequestBody(Account account, Customer customer, Ancillary ancillary) {
		super();
		this.account = account;
		this.customer = customer;
		this.ancillary = ancillary;
	}

	@JsonProperty("Account")
	Account account;
	
	@JsonProperty("Customer")
	Customer customer;
	
	@JsonProperty("Ancillary")
	Ancillary ancillary;
	
	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Ancillary getAncillery() {
		return ancillary;
	}

	public void setAncillery(Ancillary ancillery) {
		this.ancillary = ancillery;
	}
	
	public MwRequestBody() {
		super();
		// TODO Auto-generated constructor stub
	}

	

}
