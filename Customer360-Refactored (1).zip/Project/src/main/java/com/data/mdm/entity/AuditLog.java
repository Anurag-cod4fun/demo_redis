package com.data.mdm.entity;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "MDM_AUDITLOG") // Change to your actual table name
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditLog {

    @EmbeddedId
    private AuditId id;

    @Column(name = "ACCOUNTNUMBER", nullable = true, length = 50)
    private String accountNumber;

    @Lob
    @Column(name = "FIELDS")
    private String fields;

    @Lob
    @Column(name = "REQUEST")
    private String request;

    @Lob
    @Column(name = "RESPONSE")
    private String response;
}