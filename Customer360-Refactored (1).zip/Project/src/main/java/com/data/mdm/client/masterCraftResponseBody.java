//package com.data.mdm.client;
//
//public class masterCraftResponseBody {
//	
//	Root root;
//
//}
