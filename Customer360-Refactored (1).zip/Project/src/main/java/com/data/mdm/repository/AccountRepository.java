package com.data.mdm.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.data.mdm.entity.AccountEntity;


@Repository
public interface AccountRepository extends JpaRepository<AccountEntity, String> {
	
	 
}

