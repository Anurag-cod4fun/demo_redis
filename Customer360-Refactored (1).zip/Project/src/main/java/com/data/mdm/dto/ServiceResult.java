package com.data.mdm.dto;

public record ServiceResult(Status status, String message) {
    public enum Status { SUCCESS, FAILED, SKIPPED }
    public static ServiceResult success(String message) { return new ServiceResult(Status.SUCCESS, message); }
    public static ServiceResult failed(String message) { return new ServiceResult(Status.FAILED, message); }
    public static ServiceResult skipped() { return new ServiceResult(Status.SKIPPED, "Section not supplied"); }
}
