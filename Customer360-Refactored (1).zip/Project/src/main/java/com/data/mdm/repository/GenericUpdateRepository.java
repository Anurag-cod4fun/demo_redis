package com.data.mdm.repository;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaUpdate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.metamodel.Attribute;
import jakarta.persistence.metamodel.EntityType;
import jakarta.persistence.metamodel.SingularAttribute;

@Repository
public class GenericUpdateRepository {
 
    @PersistenceContext
    private EntityManager entityManager;
 
    @Transactional
    public <T> int update(T entity, Object id) {
 
        Class<T> entityClass = (Class<T>) entity.getClass();
 
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
 
        CriteriaUpdate<T> update =
                cb.createCriteriaUpdate(entityClass);
 
        Root<T> root = update.from(entityClass);
 
        EntityType<T> entityType =
                entityManager.getMetamodel().entity(entityClass);
 
        BeanWrapper wrapper = new BeanWrapperImpl(entity);
 
        String idField = null;
        int fieldCount = 0;
 
        for (SingularAttribute<? super T, ?> attribute :
                entityType.getSingularAttributes()) {
 
            String fieldName = attribute.getName();
 
            if (attribute.isId()) {
                if (idField != null) throw new IllegalArgumentException("Composite IDs are not supported by this patch method");
                idField = fieldName;
                continue;
            }
 
            if (attribute.isVersion()
                    || attribute.getPersistentAttributeType()
                       != Attribute.PersistentAttributeType.BASIC) {
                continue;
            }
 
            Object value = wrapper.getPropertyValue(fieldName);
 
            if (value == null) {
                continue;
            }
 
            if (value instanceof String str && str.isEmpty()) {
                continue;
            }
 
            update.set(root.get(fieldName), value);
            fieldCount++;
        }
 
        if (idField == null || id == null) {
            throw new IllegalArgumentException("Invalid ID");
        }
 
        if (fieldCount == 0) {
            return 0;
        }
 
        update.where(cb.equal(root.get(idField), id));
 
        return entityManager.createQuery(update).executeUpdate();
    }
}