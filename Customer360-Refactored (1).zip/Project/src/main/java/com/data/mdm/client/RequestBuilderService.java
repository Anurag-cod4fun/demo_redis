package com.data.mdm.client;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.data.mdm.dto.Customer;
import com.data.mdm.dto.CustomerRequest;

import jakarta.validation.Valid;

@Service
public class RequestBuilderService {
 
	public String buildSourceData(@Valid CustomerRequest request) {
		
		Map<Integer, String> columns = new HashMap<>();	 
		
		
		Customer req = request.body().customer();
		
		StringBuilder feedCustId = new StringBuilder();
		
		StringBuilder CurrAddress = new StringBuilder();
		StringBuilder BusAddress = new StringBuilder();
		StringBuilder fullName = new StringBuilder();


		
		feedCustId.append(req.getSourcePartyId()+"-R-101");
		fullName.append(req.getFirstName()+" " + req.getMiddleName()+" " + req.getLastName());
		BusAddress.append(req.getBusAddressLine1()+" "+req.getBusAddressLine2()+" "+req.getBusAddressLine3()  +" "+req.getBusAddressLine4() +" "+ req.getBusCity() + " "+ req.getBusState()+" "+req.getBusPin()+" " + req.getBusCountry());
		CurrAddress.append(req.getCurAddressLine1()+" "+ req.getCurAddressLine2()+" "+ req.getCurAddressLine3()+" "+req.getCurAddressLine4()+ " "+req.getCurCity() + " "+ req.getCurState()+" " +req.getCurPin()+ " "+ req.getCurCountry());


		
		columns.put(11, req.getSourceSystemCode());
		columns.put(13, feedCustId.toString());
        columns.put(16, fullName.toString());
        columns.put(23, req.getBirthDate());
        columns.put(26, req.getMobilenumber());
        columns.put(29, req.getEaddress());
        columns.put(32, req.getPanNbr());
        columns.put(33, req.getCustType());
        columns.put(48, BusAddress.toString());
        columns.put(54, req.getBusPin());
        columns.put(71, CurrAddress.toString());
        columns.put(76, req.getCurPin());
        columns.put(93, req.getMailAddressLine1());
        columns.put(98, req.getMailPin());
        columns.put(117, req.getPassportNbr());
        columns.put(118, req.getPerAddressLine1());
        columns.put(119, req.getPerCity());
        columns.put(124, req.getPerPin());
        columns.put(129, req.getDriversLicenseId());
        columns.put(141, req.getInfinityId());
        columns.put(151, req.getPassportNbr());
 
        StringBuilder result = new StringBuilder();
        
        for (int i = 1; i <= 185; i++) {
        	 
            String value = java.util.Objects.toString(columns.get(i), "");
 
            result.append(value);
            result.append("@@");
        }
      
         String string2 = "||RT_CONSOLIDATE_SEARCH_CONSOLIDATE_SEARCH.txt||CONSOLIDATE_SEARCH||4119||TCS||WEBSERVICE||RT_CONSOLIDATE_SEARCH||0||||\"";
 
         result.append(string2);
         
        return result.toString();
		
	}

	}
 