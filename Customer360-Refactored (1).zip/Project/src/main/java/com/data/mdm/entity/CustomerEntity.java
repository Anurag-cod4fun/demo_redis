package com.data.mdm.entity;


import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Table(name = "MDM_CUSTOMER_MASTER")
@Data
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@IdClass(CustomerEntityId.class)
public class CustomerEntity {

    @Id
    @Column(name = "SOURCE_PARTY_ID", length = 50, nullable = false)
    private String sourcePartyId;

    @Id
    @Column(name = "SOURCE_SYSTEM_CODE", length = 30, nullable = false)
    private String sourceSystemCode;
    
    
    @Column(name = "UCIC_VALUE", length = 50, nullable = false)
    private String ucicValue;

    @Column(name = "DEL_FLAG", length = 1)
    private String delFlag;

    @Column(name = "CUST_TYPE", length = 20)
    private String custType;

    @Column(name = "NAME_PREFIX", length = 15)
    private String namePrefix;

    @Column(name = "FIRST_NAME", length = 100)
    private String firstName;

    @Column(name = "MIDDLE_NAME", length = 100)
    private String middleName;

    @Column(name = "LAST_NAME", length = 100)
    private String lastName;

    @Column(name = "FULL_NAME", length = 300)
    private String fullName;

    @Column(name = "GENDER", length = 15)
    private String gender;

    @Column(name = "BIRTH_DATE")
    private String birthDate;

    @Column(name = "EADDRESS", length = 150)
    private String eaddress;

    @Column(name = "COUNTRY_CODE", length = 10)
    private String countryCode;

    @Column(name = "MOBILENUMBER", length = 20)
    private String mobileNumber;

    @Column(name = "PAN_NBR", length = 10)
    private String panNbr;

    @Column(name = "NAT_ID", length = 50)
    private String natId;

    @Column(name = "DRIVERS_LICENSE_ID", length = 50)
    private String driversLicenseId;

    @Column(name = "VOTERS_ID", length = 50)
    private String votersId;

    @Column(name = "FORM_60", length = 1)
    private String form60;

    @Column(name = "PASSPORT_NBR", length = 30)
    private String passportNbr;

    @Column(name = "VISA_NUMBER", length = 50)
    private String visaNumber;

    @Column(name = "VISA_TYPE", length = 30)
    private String visaType;

    @Column(name = "VISA_EXP_DATE")
    private String visaExpDate;

    @Column(name = "VISA_COUNTRY_OF_ISSUE", length = 50)
    private String visaCountryOfIssue;

    @Column(name = "TIN_COUNTRY_OF_ISSUE", length = 50)
    private String tinCountryOfIssue;

    @Column(name = "TIN_DOCCODE", length = 30)
    private String tinDoccode;

    @Column(name = "TIN_NUMBER", length = 50)
    private String tinNumber;

    @Column(name = "MINOR_FLAG", length = 1)
    private String minorFlag;
	
    @Column(name = "PARTY_ID", length = 50, nullable = false)
    private String partyId;

    @Column(name = "PER_ADDRESS_LINE2", length = 255)
    private String perAddressLine2;

    @Column(name = "PER_ADDRESS_LINE3", length = 255)
    private String perAddressLine3;

    @Column(name = "PER_ADDRESS_LINE4", length = 255)
    private String perAddressLine4;

    @Column(name = "PER_CITY", length = 100)
    private String perCity;

    @Column(name = "PER_PIN", length = 20)
    private String perPin;

    @Column(name = "PER_STATE", length = 100)
    private String perState;

    @Column(name = "PER_COUNTRY", length = 100)
    private String perCountry;

    @Column(name = "PER_MOBILENUMBER", length = 20)
    private String perMobileNumber;

    @Column(name = "SRC_CREATED_ON")
    private String srcCreatedOn;

    @Column(name = "SRC_MODIFIED_ON")
    private String srcModifiedOn;

    @Column(name = "DATE_CREATED")
    private String dateCreated;

    @Column(name = "DATE_LAST_MODIFIED")
    private String dateLastModified;

    @Column(name = "LINKAGE_IDENTIFIER", length = 100)
    private String linkageIdentifier;

    @Column(name = "CRITERIA", length = 255)
    private String criteria;

    @Column(name = "LEI", length = 20)
    private String lei;

    @Column(name = "LEI_EXPIRY_DATE")
    private String leiExpiryDate;

    @Column(name = "CIN", length = 21)
    private String cin;

    @Column(name = "GSTIN", length = 15)
    private String gstin;

    @Column(name = "BG_GRP_CD", length = 50)
    private String bgGrpCd;

    @Column(name = "REG_CD", length = 50)
    private String regCd;

    @Column(name = "NRI_FLAG", length = 10)
    private String nriFlag;

    @Column(name = "INFINITY_ID", length = 50)
    private String infinityId;

    @Column(name = "CUST_CONST", length = 50)
    private String custConst;

    @Column(name = "CUST_STAT_CODE", length = 20)
    private String custStatCode;

    @Column(name = "ID_DOC_CODE", length = 30)
    private String idDocCode;

    @Column(name = "ADDR_DOC_CODE", length = 30)
    private String addrDocCode;

    @Column(name = "ID_EXPIRY_DATE")
    private String idExpiryDate;

    @Column(name = "ADDR_EXPIRY_DATE")
    private String addrExpiryDate;

    @Column(name = "CUR_ADDRESS_LINE1", length = 255)
    private String curAddressLine1;

    @Column(name = "CUR_ADDRESS_LINE2", length = 255)
    private String curAddressLine2;

    @Column(name = "CUR_ADDRESS_LINE3", length = 255)
    private String curAddressLine3;

    @Column(name = "CUR_ADDRESS_LINE4", length = 255)
    private String curAddressLine4;

    @Column(name = "CUR_CITY", length = 100)
    private String curCity;

    @Column(name = "CUR_PIN", length = 20)
    private String curPin;

    @Column(name = "CUR_STATE", length = 100)
    private String curState;

    @Column(name = "CUR_COUNTRY", length = 100)
    private String curCountry;

    @Column(name = "CUR_MOBILENUMBER", length = 20)
    private String curMobileNumber;

    @Column(name = "PER_ADDRESS_LINE1", length = 255)
    private String perAddressLine1;

    public String getNriFlag() {
        return nriFlag;
    }

    public void setNriFlag(String nriFlag) {
        this.nriFlag = nriFlag;
    }

    public String getInfinityId() {
        return infinityId;
    }

    public void setInfinityId(String infinityId) {
        this.infinityId = infinityId;
    }

    public String getCustConst() {
        return custConst;
    }

    public void setCustConst(String custConst) {
        this.custConst = custConst;
    }

    public String getCustStatCode() {
        return custStatCode;
    }

    public void setCustStatCode(String custStatCode) {
        this.custStatCode = custStatCode;
    }

    public String getIdDocCode() {
        return idDocCode;
    }

    public void setIdDocCode(String idDocCode) {
        this.idDocCode = idDocCode;
    }

    public String getAddrDocCode() {
        return addrDocCode;
    }

    public void setAddrDocCode(String addrDocCode) {
        this.addrDocCode = addrDocCode;
    }

    public String getIdExpiryDate() {
        return idExpiryDate;
    }

    public void setIdExpiryDate(String idExpiryDate) {
        this.idExpiryDate = idExpiryDate;
    }

    public String getAddrExpiryDate() {
        return addrExpiryDate;
    }

    public void setAddrExpiryDate(String addrExpiryDate) {
        this.addrExpiryDate = addrExpiryDate;
    }

    public String getCurAddressLine1() {
        return curAddressLine1;
    }

    public void setCurAddressLine1(String curAddressLine1) {
        this.curAddressLine1 = curAddressLine1;
    }

    public String getCurAddressLine2() {
        return curAddressLine2;
    }

    public void setCurAddressLine2(String curAddressLine2) {
        this.curAddressLine2 = curAddressLine2;
    }

    public String getCurAddressLine3() {
        return curAddressLine3;
    }

    public void setCurAddressLine3(String curAddressLine3) {
        this.curAddressLine3 = curAddressLine3;
    }

    public String getCurAddressLine4() {
        return curAddressLine4;
    }

    public void setCurAddressLine4(String curAddressLine4) {
        this.curAddressLine4 = curAddressLine4;
    }

    public String getCurCity() {
        return curCity;
    }

    public void setCurCity(String curCity) {
        this.curCity = curCity;
    }

    public String getCurPin() {
        return curPin;
    }

    public void setCurPin(String curPin) {
        this.curPin = curPin;
    }

    public String getCurState() {
        return curState;
    }

    public void setCurState(String curState) {
        this.curState = curState;
    }

    public String getCurCountry() {
        return curCountry;
    }

    public void setCurCountry(String curCountry) {
        this.curCountry = curCountry;
    }

    public String getCurMobileNumber() {
        return curMobileNumber;
    }

    public void setCurMobileNumber(String curMobileNumber) {
        this.curMobileNumber = curMobileNumber;
    }

    public String getPerAddressLine1() {
        return perAddressLine1;
    }

    public void setPerAddressLine1(String perAddressLine1) {
        this.perAddressLine1 = perAddressLine1;
    }
}