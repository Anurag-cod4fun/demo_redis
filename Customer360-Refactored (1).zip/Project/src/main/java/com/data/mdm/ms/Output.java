package com.data.mdm.ms;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
 
@Data
public class Output {
 
	@JsonProperty("Record")
    private Record record;
}
 