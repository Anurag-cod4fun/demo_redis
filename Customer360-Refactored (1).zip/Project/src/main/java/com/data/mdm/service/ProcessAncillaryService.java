package com.data.mdm.service;

import com.data.mdm.db.service.AncillaryService;
import com.data.mdm.dto.CustomerRequest;
import com.data.mdm.dto.ServiceResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProcessAncillaryService {
    private final AncillaryService persistence;
    private final AuditService audit;
    public ProcessAncillaryService(AncillaryService persistence, AuditService audit) {
        this.persistence = persistence;
        this.audit = audit;
    }

    @Transactional
    public ServiceResult process(CustomerRequest request) {
        var data = request.body().ancillary();
        persistence.saveOrUpdate(persistence.mapToAncillary(request));
        audit.success(request, "Ancillary", data.getSourcePartyId(), data.getSourceSytemCode(), data.getBaseAccountNo());
        return ServiceResult.success("Ancillary processed successfully");
    }
}
