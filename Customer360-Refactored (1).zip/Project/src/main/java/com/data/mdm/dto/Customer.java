package com.data.mdm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Customer {
	
	@JsonProperty("addrDocCode")
	private String addrDocCode;

	@JsonProperty("addressChangeDate")
	private String addressChangeDate;

	@JsonProperty("birthDate")
	private String birthDate;

	@JsonProperty("busAddressLine1")
	private String busAddressLine1;

	@JsonProperty("busAddressLine2")
	private String busAddressLine2;

	@JsonProperty("busAddressLine3")
	private String busAddressLine3;

	@JsonProperty("busAddressLine4")
	private String busAddressLine4;

	@JsonProperty("busCity")
	private String busCity;

	@JsonProperty("busCountry")
	private String busCountry;

	@JsonProperty("busEaddress")
	private String busEaddress;

	@JsonProperty("busMobilenumber")
	private String busMobilenumber;

	@JsonProperty("busPin")
	private String busPin;

	@JsonProperty("busState")
	private String busState;

	@JsonProperty("busphone1")
	private String busphone1;

	@JsonProperty("busphone2")
	private String busphone2;

	@JsonProperty("criteria")
	private String criteria;

	@JsonProperty("curAddressLine1")
	private String curAddressLine1;

	@JsonProperty("curAddressLine2")
	private String curAddressLine2;

	@JsonProperty("curAddressLine3")
	private String curAddressLine3;

	@JsonProperty("curAddressLine4")
	private String curAddressLine4;

	@JsonProperty("curCity")
	private String curCity;

	@JsonProperty("curCountry")
	private String curCountry;

	@JsonProperty("curEaddress")
	private String curEaddress;

	@JsonProperty("curMobilenumber")
	private String curMobilenumber;

	@JsonProperty("curPin")
	private String curPin;

	@JsonProperty("curState")
	private String curState;

	@JsonProperty("curphone1")
	private String curphone1;

	@JsonProperty("curphone2")
	private String curphone2;

	@JsonProperty("custConst")
	private String custConst;

	@JsonProperty("custStatCode")
	private String custStatCode;

	@JsonProperty("custType")
	private String custType;

	@JsonProperty("driversLicenseId")
	private String driversLicenseId;

	@JsonProperty("eaddress")
	private String eaddress;

	@JsonProperty("firstName")
	private String firstName;

	@JsonProperty("form60")
	private String form60;

	@JsonProperty("")
	private String fullName;

	@JsonProperty("")
	private String gender;

	@JsonProperty("")
	private String idDocCode;

	@JsonProperty("")
	private String infinityId;

	@JsonProperty("")
	private String lastName;

	@JsonProperty("")
	private String linkageIdentifier;

	@JsonProperty("")
	private String mailAddressLine1;

	@JsonProperty("")
	private String mailAddressLine2;

	@JsonProperty("")
	private String mailAddressLine3;

	@JsonProperty("")
	private String mailAddressLine4;

	@JsonProperty("")
	private String mailCity;

	@JsonProperty("")
	private String mailCountry;

	@JsonProperty("")
	private String mailEaddress;

	@JsonProperty("")
	private String mailMobilenumber;

	@JsonProperty("")
	private String mailPin;

	@JsonProperty("")
	private String mailState;

	@JsonProperty("")
	private String mailphone1;

	@JsonProperty("")
	private String mailphone2;

	@JsonProperty("")
	private String middleName;

	@JsonProperty("")
	private String minorFlag;

	@JsonProperty("mobilenumber")
	private String mobilenumber;

	@JsonProperty("namePrefix")
	private String namePrefix;

	@JsonProperty("natId")
	private String natId;

	@JsonProperty("nriFlag")
	private String nriFlag;

	@JsonProperty("panNbr")
	private String panNbr;

	@JsonProperty("partyId")
	private String partyId;

	@JsonProperty("passportIssueDate")
	private String passportIssueDate;

	@JsonProperty("passportNbr")
	private String passportNbr;

	@JsonProperty("perAddressFlag")
	private String perAddressFlag;

	@JsonProperty("perAddressLine1")
	private String perAddressLine1;

	@JsonProperty("perAddressLine2")
	private String perAddressLine2;

	@JsonProperty("perAddressLine3")
	private String perAddressLine3;

	@JsonProperty("perAddressLine4")
	private String perAddressLine4;

	@JsonProperty("perCity")
	private String perCity;

	@JsonProperty("perCountry")
	private String perCountry;

	@JsonProperty("perEaddress")
	private String perEaddress;

	@JsonProperty("perMobilenumber")
	private String perMobilenumber;

	@JsonProperty("perPin")
	private String perPin;

	@JsonProperty("perState")
	private String perState;

	@JsonProperty("perphone1")
	private String perphone1;

	@JsonProperty("perphone2")
	private String perphone2;

	@JsonProperty("tinCountryOfIssue")
	private String tinCountryOfIssue;

	@JsonProperty("tinDoccode")
	private String tinDoccode;

	@JsonProperty("tinNumber")
	private String tinNumber;

	@JsonProperty("ucicValue")
	private String ucicValue;

	@JsonProperty("visaCountryOfIssue")
	private String visaCountryOfIssue;

	@JsonProperty("visaExpDate")
	private String visaExpDate;

	@JsonProperty("visaNumber")
	private String visaNumber;

	@JsonProperty("visaType")
	private String visaType;

	@JsonProperty("votersId")
	private String votersId;

	@JsonProperty("countryCode")
	private String countryCode;

	@JsonProperty("dateLastModified")
	private String dateLastModified;

	@JsonProperty("sourcePartyI")
	private String sourcePartyI;

	@JsonProperty("sourceSystemCode")
	private String sourceSystemCode;

	@JsonProperty("srcCreatedOn")
	private String srcCreatedOn;

	@JsonProperty("srcModifiedOn")
	private String srcModifiedOn;

	@JsonProperty("dateCreated")
	private String dateCreated;

	private String sourcePartyId;

	public String getAddrDocCode() {
		return addrDocCode;
	}

	public void setAddrDocCode(String addrDocCode) {
		this.addrDocCode = addrDocCode;
	}

	public String getAddressChangeDate() {
		return addressChangeDate;
	}

	public void setAddressChangeDate(String addressChangeDate) {
		this.addressChangeDate = addressChangeDate;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getBusAddressLine1() {
		return busAddressLine1;
	}

	public void setBusAddressLine1(String busAddressLine1) {
		this.busAddressLine1 = busAddressLine1;
	}

	public String getBusAddressLine2() {
		return busAddressLine2;
	}

	public void setBusAddressLine2(String busAddressLine2) {
		this.busAddressLine2 = busAddressLine2;
	}

	public String getBusAddressLine3() {
		return busAddressLine3;
	}

	public void setBusAddressLine3(String busAddressLine3) {
		this.busAddressLine3 = busAddressLine3;
	}

	public String getBusAddressLine4() {
		return busAddressLine4;
	}

	public void setBusAddressLine4(String busAddressLine4) {
		this.busAddressLine4 = busAddressLine4;
	}

	public String getBusCity() {
		return busCity;
	}

	public void setBusCity(String busCity) {
		this.busCity = busCity;
	}

	public String getBusCountry() {
		return busCountry;
	}

	public void setBusCountry(String busCountry) {
		this.busCountry = busCountry;
	}

	public String getBusEaddress() {
		return busEaddress;
	}

	public void setBusEaddress(String busEaddress) {
		this.busEaddress = busEaddress;
	}

	public String getBusMobilenumber() {
		return busMobilenumber;
	}

	public void setBusMobilenumber(String busMobilenumber) {
		this.busMobilenumber = busMobilenumber;
	}

	public String getBusPin() {
		return busPin;
	}

	public void setBusPin(String busPin) {
		this.busPin = busPin;
	}

	public String getBusState() {
		return busState;
	}

	public void setBusState(String busState) {
		this.busState = busState;
	}

	public String getBusphone1() {
		return busphone1;
	}

	public void setBusphone1(String busphone1) {
		this.busphone1 = busphone1;
	}

	public String getBusphone2() {
		return busphone2;
	}

	public void setBusphone2(String busphone2) {
		this.busphone2 = busphone2;
	}

	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}

	public String getCurAddressLine1() {
		return curAddressLine1;
	}

	public void setCurAddressLine1(String curAddressLine1) {
		this.curAddressLine1 = curAddressLine1;
	}

	public String getCurAddressLine2() {
		return curAddressLine2;
	}

	public void setCurAddressLine2(String curAddressLine2) {
		this.curAddressLine2 = curAddressLine2;
	}

	public String getCurAddressLine3() {
		return curAddressLine3;
	}

	public void setCurAddressLine3(String curAddressLine3) {
		this.curAddressLine3 = curAddressLine3;
	}

	public String getCurAddressLine4() {
		return curAddressLine4;
	}

	public void setCurAddressLine4(String curAddressLine4) {
		this.curAddressLine4 = curAddressLine4;
	}

	public String getCurCity() {
		return curCity;
	}

	public void setCurCity(String curCity) {
		this.curCity = curCity;
	}

	public String getCurCountry() {
		return curCountry;
	}

	public void setCurCountry(String curCountry) {
		this.curCountry = curCountry;
	}

	public String getCurEaddress() {
		return curEaddress;
	}

	public void setCurEaddress(String curEaddress) {
		this.curEaddress = curEaddress;
	}

	public String getCurMobilenumber() {
		return curMobilenumber;
	}

	public void setCurMobilenumber(String curMobilenumber) {
		this.curMobilenumber = curMobilenumber;
	}

	public String getCurPin() {
		return curPin;
	}

	public void setCurPin(String curPin) {
		this.curPin = curPin;
	}

	public String getCurState() {
		return curState;
	}

	public void setCurState(String curState) {
		this.curState = curState;
	}

	public String getCurphone1() {
		return curphone1;
	}

	public void setCurphone1(String curphone1) {
		this.curphone1 = curphone1;
	}

	public String getCurphone2() {
		return curphone2;
	}

	public void setCurphone2(String curphone2) {
		this.curphone2 = curphone2;
	}

	public String getCustConst() {
		return custConst;
	}

	public void setCustConst(String custConst) {
		this.custConst = custConst;
	}

	public String getCustStatCode() {
		return custStatCode;
	}

	public void setCustStatCode(String custStatCode) {
		this.custStatCode = custStatCode;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public String getDriversLicenseId() {
		return driversLicenseId;
	}

	public void setDriversLicenseId(String driversLicenseId) {
		this.driversLicenseId = driversLicenseId;
	}

	public String getEaddress() {
		return eaddress;
	}

	public void setEaddress(String eaddress) {
		this.eaddress = eaddress;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getForm60() {
		return form60;
	}

	public void setForm60(String form60) {
		this.form60 = form60;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIdDocCode() {
		return idDocCode;
	}

	public void setIdDocCode(String idDocCode) {
		this.idDocCode = idDocCode;
	}

	public String getInfinityId() {
		return infinityId;
	}

	public void setInfinityId(String infinityId) {
		this.infinityId = infinityId;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLinkageIdentifier() {
		return linkageIdentifier;
	}

	public void setLinkageIdentifier(String linkageIdentifier) {
		this.linkageIdentifier = linkageIdentifier;
	}

	public String getMailAddressLine1() {
		return mailAddressLine1;
	}

	public void setMailAddressLine1(String mailAddressLine1) {
		this.mailAddressLine1 = mailAddressLine1;
	}

	public String getMailAddressLine2() {
		return mailAddressLine2;
	}

	public void setMailAddressLine2(String mailAddressLine2) {
		this.mailAddressLine2 = mailAddressLine2;
	}

	public String getMailAddressLine3() {
		return mailAddressLine3;
	}

	public void setMailAddressLine3(String mailAddressLine3) {
		this.mailAddressLine3 = mailAddressLine3;
	}

	public String getMailAddressLine4() {
		return mailAddressLine4;
	}

	public void setMailAddressLine4(String mailAddressLine4) {
		this.mailAddressLine4 = mailAddressLine4;
	}

	public String getMailCity() {
		return mailCity;
	}

	public void setMailCity(String mailCity) {
		this.mailCity = mailCity;
	}

	public String getMailCountry() {
		return mailCountry;
	}

	public void setMailCountry(String mailCountry) {
		this.mailCountry = mailCountry;
	}

	public String getMailEaddress() {
		return mailEaddress;
	}

	public void setMailEaddress(String mailEaddress) {
		this.mailEaddress = mailEaddress;
	}

	public String getMailMobilenumber() {
		return mailMobilenumber;
	}

	public void setMailMobilenumber(String mailMobilenumber) {
		this.mailMobilenumber = mailMobilenumber;
	}

	public String getMailPin() {
		return mailPin;
	}

	public void setMailPin(String mailPin) {
		this.mailPin = mailPin;
	}

	public String getMailState() {
		return mailState;
	}

	public void setMailState(String mailState) {
		this.mailState = mailState;
	}

	public String getMailphone1() {
		return mailphone1;
	}

	public void setMailphone1(String mailphone1) {
		this.mailphone1 = mailphone1;
	}

	public String getMailphone2() {
		return mailphone2;
	}

	public void setMailphone2(String mailphone2) {
		this.mailphone2 = mailphone2;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getMinorFlag() {
		return minorFlag;
	}

	public void setMinorFlag(String minorFlag) {
		this.minorFlag = minorFlag;
	}

	public String getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public String getNamePrefix() {
		return namePrefix;
	}

	public void setNamePrefix(String namePrefix) {
		this.namePrefix = namePrefix;
	}

	public String getNatId() {
		return natId;
	}

	public void setNatId(String natId) {
		this.natId = natId;
	}

	public String getNriFlag() {
		return nriFlag;
	}

	public void setNriFlag(String nriFlag) {
		this.nriFlag = nriFlag;
	}

	public String getPanNbr() {
		return panNbr;
	}

	public void setPanNbr(String panNbr) {
		this.panNbr = panNbr;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getPassportIssueDate() {
		return passportIssueDate;
	}

	public void setPassportIssueDate(String passportIssueDate) {
		this.passportIssueDate = passportIssueDate;
	}

	public String getPassportNbr() {
		return passportNbr;
	}

	public void setPassportNbr(String passportNbr) {
		this.passportNbr = passportNbr;
	}

	public String getPerAddressFlag() {
		return perAddressFlag;
	}

	public void setPerAddressFlag(String perAddressFlag) {
		this.perAddressFlag = perAddressFlag;
	}

	public String getPerAddressLine1() {
		return perAddressLine1;
	}

	public void setPerAddressLine1(String perAddressLine1) {
		this.perAddressLine1 = perAddressLine1;
	}

	public String getPerAddressLine2() {
		return perAddressLine2;
	}

	public void setPerAddressLine2(String perAddressLine2) {
		this.perAddressLine2 = perAddressLine2;
	}

	public String getPerAddressLine3() {
		return perAddressLine3;
	}

	public void setPerAddressLine3(String perAddressLine3) {
		this.perAddressLine3 = perAddressLine3;
	}

	public String getPerAddressLine4() {
		return perAddressLine4;
	}

	public void setPerAddressLine4(String perAddressLine4) {
		this.perAddressLine4 = perAddressLine4;
	}

	public String getPerCity() {
		return perCity;
	}

	public void setPerCity(String perCity) {
		this.perCity = perCity;
	}

	public String getPerCountry() {
		return perCountry;
	}

	public void setPerCountry(String perCountry) {
		this.perCountry = perCountry;
	}

	public String getPerEaddress() {
		return perEaddress;
	}

	public void setPerEaddress(String perEaddress) {
		this.perEaddress = perEaddress;
	}

	public String getPerMobilenumber() {
		return perMobilenumber;
	}

	public void setPerMobilenumber(String perMobilenumber) {
		this.perMobilenumber = perMobilenumber;
	}

	public String getPerPin() {
		return perPin;
	}

	public void setPerPin(String perPin) {
		this.perPin = perPin;
	}

	public String getPerState() {
		return perState;
	}

	public void setPerState(String perState) {
		this.perState = perState;
	}

	public String getPerphone1() {
		return perphone1;
	}

	public void setPerphone1(String perphone1) {
		this.perphone1 = perphone1;
	}

	public String getPerphone2() {
		return perphone2;
	}

	public void setPerphone2(String perphone2) {
		this.perphone2 = perphone2;
	}

	public String getTinCountryOfIssue() {
		return tinCountryOfIssue;
	}

	public void setTinCountryOfIssue(String tinCountryOfIssue) {
		this.tinCountryOfIssue = tinCountryOfIssue;
	}

	public String getTinDoccode() {
		return tinDoccode;
	}

	public void setTinDoccode(String tinDoccode) {
		this.tinDoccode = tinDoccode;
	}

	public String getTinNumber() {
		return tinNumber;
	}

	public void setTinNumber(String tinNumber) {
		this.tinNumber = tinNumber;
	}

	public String getUcicValue() {
		return ucicValue;
	}

	public void setUcicValue(String ucicValue) {
		this.ucicValue = ucicValue;
	}

	public String getVisaCountryOfIssue() {
		return visaCountryOfIssue;
	}

	public void setVisaCountryOfIssue(String visaCountryOfIssue) {
		this.visaCountryOfIssue = visaCountryOfIssue;
	}

	public String getVisaExpDate() {
		return visaExpDate;
	}

	public void setVisaExpDate(String visaExpDate) {
		this.visaExpDate = visaExpDate;
	}

	public String getVisaNumber() {
		return visaNumber;
	}

	public void setVisaNumber(String visaNumber) {
		this.visaNumber = visaNumber;
	}

	public String getVisaType() {
		return visaType;
	}

	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}

	public String getVotersId() {
		return votersId;
	}

	public void setVotersId(String votersId) {
		this.votersId = votersId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getDateLastModified() {
		return dateLastModified;
	}

	public void setDateLastModified(String dateLastModified) {
		this.dateLastModified = dateLastModified;
	}

	public String getSourcePartyId() {
		return sourcePartyId;
	}

	public void setSourcePartyId(String sourcePartyId) {
		this.sourcePartyId = sourcePartyId;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public String getSrcCreatedOn() {
		return srcCreatedOn;
	}

	public void setSrcCreatedOn(String srcCreatedOn) {
		this.srcCreatedOn = srcCreatedOn;
	}

	public String getSrcModifiedOn() {
		return srcModifiedOn;
	}

	public void setSrcModifiedOn(String srcModifiedOn) {
		this.srcModifiedOn = srcModifiedOn;
	}

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}

}
