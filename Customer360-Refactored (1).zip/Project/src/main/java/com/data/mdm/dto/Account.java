package com.data.mdm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Account {
	
	@JsonProperty("sourcePartyId")
	private String sourcePartyId;
	
	@JsonProperty("sourceSystemCode")
	private String sourceSytemCode;
	
	@JsonProperty("accHolder")
    private String accHolder;

	@JsonProperty("accountClsDate")
    private String accountClsDate;

	@JsonProperty("accountOpenDate")
    private String accountOpenDate;

	@JsonProperty("accountStatus")
    private String accountStatus;

	@JsonProperty("accountType")
    private String accountType;

	@JsonProperty("accountTypeCode")
    private String accountTypeCode;

	@JsonProperty("acctOwnership")
    private String acctOwnership;

	@JsonProperty("closedFlag")
    private String closedFlag;

	@JsonProperty("delinquencyFlag")
    private String delinquencyFlag;

	@JsonProperty("forecloseBlockCode")
    private String forecloseBlockCode;

	@JsonProperty("lienReasonCode")
    private String lienReasonCode;

	@JsonProperty("productId")
    private String productId;

	@JsonProperty("productType")
    private String producttype;

	@JsonProperty("relationWithPrimary")
    private String relationWithPrimary;

	@JsonProperty("schemeCode")
    private String schemeCode;

	@JsonProperty("schmType")
    private String schmType;

	@JsonProperty("sourceAccountNumber")
    private String sourceAccountNumber;

	@JsonProperty("sourceOfFunds")
    private String sourceOfFunds;

	@JsonProperty("frezReasonCode")
    private String frezReasonCode;

	@JsonProperty("frezReasonCode2")
    private String frezReasonCode2;

	@JsonProperty("frezReasonCode3")
    private String frezReasonCode3;

	@JsonProperty("frezReasonCode4")
    private String frezReasonCode4;

	@JsonProperty("frezReasonCode5")
    private String frezReasonCode5;

	@JsonProperty("freezeRodeFlag")
    private String freezeRodeFlag;

	@JsonProperty("fnominee")
    private String fnominee;

	@JsonProperty("nriStatus")
    private String nriStatus;
	
	@JsonProperty("DateCreated")
	private String DateCreated;

	@JsonProperty("DateLastModified")
	private String DateLastModified;

	@JsonProperty("SrcCreatedOn")
	private String SrcCreatedOn;

	@JsonProperty("SrcModifiedOn")
	private String SrcModifiedOn;

	@JsonProperty("")
    public String getAccHolder() {
        return accHolder;
    }

    public void setAccHolder(String accHolder) {
        this.accHolder = accHolder;
    }

    public String getAccountClaDate() {
        return accountClsDate;
    }

    public void setAccountClaDate(String accountClaDate) {
        this.accountClsDate = accountClaDate;
    }

    public String getAccountOpenDate() {
        return accountOpenDate;
    }

    public void setAccountOpenDate(String accountOpenDate) {
        this.accountOpenDate = accountOpenDate;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAccountTypeCode() {
        return accountTypeCode;
    }

    public void setAccountTypeCode(String accountTypeCode) {
        this.accountTypeCode = accountTypeCode;
    }

    public String getAcctOwnership() {
        return acctOwnership;
    }

    public void setAcctOwnership(String acctOwnership) {
        this.acctOwnership = acctOwnership;
    }

    public String getClosedFlag() {
        return closedFlag;
    }

    public void setClosedFlag(String closedFlag) {
        this.closedFlag = closedFlag;
    }

    public String getDelinquencyFlag() {
        return delinquencyFlag;
    }

    public void setDelinquencyFlag(String delinquencyFlag) {
        this.delinquencyFlag = delinquencyFlag;
    }

    public String getForecloseBlockCode() {
        return forecloseBlockCode;
    }

    public void setForecloseBlockCode(String forecloseBlockCode) {
        this.forecloseBlockCode = forecloseBlockCode;
    }

    public String getLienReasonCode() {
        return lienReasonCode;
    }

    public void setLienReasonCode(String lienReasonCode) {
        this.lienReasonCode = lienReasonCode;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProducttype() {
        return producttype;
    }

    public void setProducttype(String producttype) {
        this.producttype = producttype;
    }

    public String getRelationWithPrimary() {
        return relationWithPrimary;
    }

    public void setRelationWithPrimary(String relationWithPrimary) {
        this.relationWithPrimary = relationWithPrimary;
    }

    public String getSchemeCode() {
        return schemeCode;
    }

    public void setSchemeCode(String schemeCode) {
        this.schemeCode = schemeCode;
    }

    public String getSchmType() {
        return schmType;
    }

    public void setSchmType(String schmType) {
        this.schmType = schmType;
    }

    public String getSourceAccountNumber() {
        return sourceAccountNumber;
    }

    public void setSourceAccountNumber(String sourceAccountNumber) {
        this.sourceAccountNumber = sourceAccountNumber;
    }

    public String getSourceOfFunds() {
        return sourceOfFunds;
    }

    public void setSourceOfFunds(String sourceOfFunds) {
        this.sourceOfFunds = sourceOfFunds;
    }

    public String getFrezReasonCode() {
        return frezReasonCode;
    }

    public void setFrezReasonCode(String frezReasonCode) {
        this.frezReasonCode = frezReasonCode;
    }

    public String getFrezReasonCode2() {
        return frezReasonCode2;
    }

    public void setFrezReasonCode2(String frezReasonCode2) {
        this.frezReasonCode2 = frezReasonCode2;
    }

    public String getFrezReasonCode3() {
        return frezReasonCode3;
    }

    public void setFrezReasonCode3(String frezReasonCode3) {
        this.frezReasonCode3 = frezReasonCode3;
    }

    public String getFrezReasonCode4() {
        return frezReasonCode4;
    }

    public void setFrezReasonCode4(String frezReasonCode4) {
        this.frezReasonCode4 = frezReasonCode4;
    }

    public String getFrezReasonCode5() {
        return frezReasonCode5;
    }

    public void setFrezReasonCode5(String frezReasonCode5) {
        this.frezReasonCode5 = frezReasonCode5;
    }

    public String getFreezeRodeFlag() {
        return freezeRodeFlag;
    }

    public void setFreezeRodeFlag(String freezeRodeFlag) {
        this.freezeRodeFlag = freezeRodeFlag;
    }

    public String getFnominee() {
        return fnominee;
    }

    public void setFnominee(String fnominee) {
        this.fnominee = fnominee;
    }

    public String getNriStatus() {
        return nriStatus;
    }

    public void setNriStatus(String nriStatus) {
        this.nriStatus = nriStatus;
    }

	public String getSourcePartyId() {
		// TODO Auto-generated method stub
		return sourcePartyId;
	}

	public String getSourceSystemCode() {
		// TODO Auto-generated method stub
		return sourceSytemCode;
	}

	public String getDateCreated() {
		// TODO Auto-generated method stub
		return DateCreated;
	}

	public String getDateLastModified() {
		// TODO Auto-generated method stub
		return DateLastModified;
	}

	public String getSrcCreatedOn() {
		// TODO Auto-generated method stub
		return SrcCreatedOn;
	}




    public String getSrcModifiedOn() { return SrcModifiedOn; }
}
