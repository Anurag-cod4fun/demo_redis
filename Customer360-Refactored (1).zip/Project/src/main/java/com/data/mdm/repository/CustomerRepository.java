package com.data.mdm.repository;

import com.data.mdm.entity.CustomerEntity;
import com.data.mdm.entity.CustomerEntityId;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface CustomerRepository extends JpaRepository<CustomerEntity, CustomerEntityId> {
    Optional<CustomerEntity> findByUcicValue(String ucicValue);
    Optional<CustomerEntity> findBySourcePartyIdAndSourceSystemCode(String sourcePartyId, String sourceSystemCode);
}
