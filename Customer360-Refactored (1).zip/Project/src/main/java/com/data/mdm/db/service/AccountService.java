package com.data.mdm.db.service;

import org.springframework.stereotype.Service;

import com.data.mdm.dto.CustomerRequest;
import com.data.mdm.entity.AccountEntity;
import com.data.mdm.repository.AccountRepository;
import com.data.mdm.repository.GenericUpdateRepository;

@Service
public class AccountService {
 
    private final AccountRepository accountRepository;
  
    private final GenericUpdateRepository genericUpdateRepository;
 
    public AccountService(AccountRepository accountRepository,GenericUpdateRepository genericUpdateRepository) {
        this.accountRepository = accountRepository;
        this.genericUpdateRepository=genericUpdateRepository;
    }
    
    public AccountEntity  mapToAccount(CustomerRequest request) {
    	
    	var data = request.body().account();
        return AccountEntity.builder()
				.sourcePartyId(data.getSourcePartyId())
				.sourceAccountNumber(data.getSourceAccountNumber())
				.sourceSystemCode(data.getSourceSystemCode())
				.accountOpenDate(data.getAccountOpenDate())
				.accountCloseDate(data.getAccountClaDate())
				.accountStatus(data.getAccountStatus())
				.closedFlag(data.getClosedFlag())
				.schemeCode(data.getSchemeCode())
				.accHolder(data.getAccHolder())
				.accountType(data.getAccountType())

				.productId(data.getProductId())
				.productType(data.getProducttype())
				.relationWithPrimary(data.getRelationWithPrimary())

				.forecloseBlockCode(data.getForecloseBlockCode())
				.lienReasonCode(data.getLienReasonCode())
				.sourceOfFunds(data.getSourceOfFunds())
				.frezReasonCode(data.getFrezReasonCode())

				.freezeCodeFlag(data.getFreezeRodeFlag())
				.fNominee(data.getFnominee())
				.nriStatus(data.getNriStatus())
				.dateCreated(data.getDateCreated())
				.dateLastModified(data.getDateLastModified())
				.srcCreatedOn(data.getSrcCreatedOn())
				.srcModifiedOn(data.getSrcModifiedOn())
				.build();
    }

    public void saveOrUpdate(AccountEntity accountdata) {

        boolean isUpdate = accountdata.getSourceAccountNumber() != null 
                           && accountRepository.existsById(accountdata.getSourceAccountNumber());

        if (isUpdate) {

            genericUpdateRepository.update(accountdata, accountdata.getSourceAccountNumber());
        } else {

            accountRepository.save(accountdata);
        }
    }

}