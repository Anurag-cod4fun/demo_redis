package com.data.mdm.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "MDM_CUSTOMER_ANCILLARY")
@Data
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AncillaryEntity { 
    
	@Id 
    @Column(name = "SOURCEPARTYID") 
    public String sourcePartyId; 
    
    @Column(name = "SOURCESYSTEMCODE") 
    public String sourceSystemCode; 
    
    @Column(name = "CKYCID") 
    public String ckycId; 
    
    @Column(name = "NATIONALITY") 
    public String nationality; 
    
    @Column(name = "MARITALSTATUS") 
    public String maritalStatus; 
    
    @Column(name = "FATHERNAME") 
    public String fatherName; 
    
    @Column(name = "MOTHERNAME") 
    public String motherName; 
    
    @Column(name = "SPOUSENAME") 
    public String spouseName; 
    
    @Column(name = "DISABLEPERSON") 
    public String disablePerson; 
    
    @Column(name = "RMID") 
    public String rmId; 
    
    @Column(name = "RELIGION") 
    public String religion; 
    
    @Column(name = "CUSTOMERSEGMENT") 
    public String customerSegment; 
    
    @Column(name = "SERVICESEGMENT") 
    public String serviceSegment; 
    
    @Column(name = "AGRIINCOME") 
    public String agriIncome; 
    
    @Column(name = "NONAGRIINCOME") 
    public String nonAgriIncome; 
    
    @Column(name = "ANNUALINCOME") 
    public String annualIncome; 
    
    @Column(name = "GROSSANNUALINCOME") 
    public String grossAnnualIncome; 
    
    @Column(name = "SALARY") 
    public String salary; 
    
    @Column(name = "ANNUALSALES") 
    public String annualSales; 
    
    @Column(name = "BUSITURNOVER") 
    public String busiTurnover; 
    
    @Column(name = "BASICQUALIFICATION") 
    public String basicQualification; 
    
    @Column(name = "PROFQUALIFICATION") 
    public String profQualification; 
    
    @Column(name = "PROFESSION") 
    public String profession; 
    
    @Column(name = "DESIGNATION") 
    public String designation; 
    
    @Column(name = "INDUSTRY") 
    public String industry; 
    
    @Column(name = "OCCUPATIONTYPE") 
    public String occupationType; 
    
    @Column(name = "EMPLOYMENTTYPE") 
    public String employmentType; 
    
    @Column(name = "CUSEMPLOYER") 
    public String cusEmployer; 
    
    @Column(name = "BSRCODE") 
    public String bsrCode; 
    
    @Column(name = "FATCAFLAG") 
    public String fatcaFlag; 
    
    @Column(name = "DATEOFBECOMINGNRI") 
    public String dateOfBecomingNri; 
    
    @Column(name = "EMPLOYEEID") 
    public String employeeId; 
    
    @Column(name = "TOTYRSOFEXPERIENCE") 
    public String totYrsOfExperience; 
    
    @Column(name = "NOOFEMPLOYEES") 
    public String noOfEmployees; 
    
    @Column(name = "LEGALGUARDIAN") 
    public String legalGuardian; 
    
    @Column(name = "BASEACCOUNTNO") 
    public String baseAccountNo; 
    
    @Column(name = "DATACLASSNAME") 
    public String dataClassName; 
    
    @Column(name = "IVIEWIMAGEREFERENCE") 
    public String iviewImageReference; 
    
    @Column(name = "TRACKINGNO") 
    public String trackingNo; 
    
    @Column(name = "COUNTRYFLAG") 
    public String countryFlag; 
    
    @Column(name = "ONEKYCFLAG") 
    public String onekycFlag; 
    
    @Column(name = "REKYCFLAG") 
    public String rekycFlag; 
    
    @Column(name = "VIDEOKYCCUSTID") 
    public String videokycCustid; 
    
    @Column(name = "VIDEOKYCFLAG") 
    public String videokycFlag; 
    
    @Column(name = "ADDRPROOFCOLOURCODE") 
    public String addrProofColourcode; 
    
    @Column(name = "IDPROOFCOLOURCODE") 
    public String idProofColourcode; 
    
    @Column(name = "ASSETADDRPROOFCOLOURCODE") 
    public String assetAddrProofColourcode; 
    
    @Column(name = "ASSETIDPROOFCOLOURCODE") 
    public String assetIdProofColourcode; 
    
    @Column(name = "DATECREATED") 
    public String dateCreated; 
    
    @Column(name = "DATELASTMODIFIED") 
    public String dateLastModified; 
    
    @Column(name = "SRCCREATEDON") 
    public String srcCreatedOn; 
    
    @Column(name = "SRCMODIFIEDON") 
    public String srcModifiedOn; 
    
    @Column(name = "ADDRESSDOCLINK") 
    public String addressDoclink; 
    
    @Column(name = "IDDOCLINK") 
    public String idDoclink; 
    
    @Column(name = "PHOTODOCLINK") 
    public String photoDoclink; 
    
    @Column(name = "DOCUMENTLINK") 
    public String documentLink; 
    
    @Column(name = "KYCDOCLINK") 
    public String kycDoclink; 
    
    @Column(name = "UPDATEDDOCUMENTLINK") 
    public String updatedDocumentLink; 
}
