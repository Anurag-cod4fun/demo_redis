package com.data.mdm.service;

import com.data.mdm.dto.CustomerRequest;
import com.data.mdm.entity.*;
import com.data.mdm.repository.AuditLogRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
public class AuditService {
    private final AuditLogRepository repository;
    public AuditService(AuditLogRepository repository) { this.repository = repository; }

    public void success(CustomerRequest request, String section, String partyId, String systemCode, String accountNumber) {
        var audit = new AuditLog();
        audit.setId(new AuditId(systemCode, partyId, LocalDateTime.now()));
        audit.setFields(section);
        audit.setAccountNumber(accountNumber);
        audit.setRequest("traceId=" + request.head().trcID());
        audit.setResponse("Success");
        repository.save(audit);
    }
}
