package com.data.mdm.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "API_AUDIT")
public class ApiAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "TRC_ID", nullable = false)
    private String trcId;

    @Column(name = "OPERATION_FLAG")
    private String operationFlag;

    @Column(name = "REQUEST_JSON", columnDefinition = "CLOB")
    private String requestJson;

    @Column(name = "RESPONSE_JSON", columnDefinition = "CLOB")
    private String responseJson;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;

    public Long getId() { return id; }
    public String getTrcId() { return trcId; }
    public void setTrcId(String trcId) { this.trcId = trcId; }
    public String getOperationFlag() { return operationFlag; }
    public void setOperationFlag(String operationFlag) { this.operationFlag = operationFlag; }
    public String getRequestJson() { return requestJson; }
    public void setRequestJson(String requestJson) { this.requestJson = requestJson; }
    public String getResponseJson() { return responseJson; }
    public void setResponseJson(String responseJson) { this.responseJson = responseJson; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
