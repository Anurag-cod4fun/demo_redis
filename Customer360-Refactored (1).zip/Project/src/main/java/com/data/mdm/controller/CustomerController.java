package com.data.mdm.controller;

import com.data.mdm.dto.CustomerRequest;
import com.data.mdm.dto.FinalApiResponse;
import com.data.mdm.service.CustomerOrchestrationService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/v1/customer")
public class CustomerController {
    private final CustomerOrchestrationService orchestration;

    public CustomerController(CustomerOrchestrationService orchestration) {
        this.orchestration = orchestration;
    }

    @PostMapping("/ucic")
    public CompletableFuture<FinalApiResponse> dispatch(@Valid @RequestBody CustomerRequest request) {
        return orchestration.process(request);
    }
}
