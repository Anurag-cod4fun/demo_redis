package com.data.mdm.controller;

import com.data.mdm.dto.ErrorResponse;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.server.ResponseStatusException;
import java.time.OffsetDateTime;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<ErrorResponse> status(ResponseStatusException ex) {
        return ResponseEntity.status(ex.getStatusCode()).body(error(ex.getStatusCode().value(), ex.getReason()));
    }
    @ExceptionHandler({MethodArgumentNotValidException.class, org.springframework.http.converter.HttpMessageNotReadableException.class})
    public ResponseEntity<ErrorResponse> invalid(Exception ex) {
        return ResponseEntity.badRequest().body(error(400, "Invalid request body or required fields"));
    }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> unexpected(Exception ex) {
        return ResponseEntity.internalServerError().body(error(500, "Unexpected processing error"));
    }
    private ErrorResponse error(int status, String message) {
        return new ErrorResponse(OffsetDateTime.now().toString(), status, HttpStatus.valueOf(status).name(), message, null);
    }
}
