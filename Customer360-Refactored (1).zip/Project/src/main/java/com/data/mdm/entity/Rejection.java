package com.data.mdm.entity;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;

@Entity
@Table(name = "MDM_REJECTION")

public class Rejection {

    @EmbeddedId
    private RejectionId id;

    @Column(name = "REASON", nullable = true, length = 500)
    private String reason;

    @Column(name = "FIELDSVALUE", nullable = false, length = 255)
    private String fieldValue;

    @Column(name = "FIELDNAME", nullable = false, length = 100)
    private String fieldName;

    
    @Column(name = "TYPE", nullable = false, length = 20)
    private String type;

    // Default constructor required by JPA
    public Rejection() {
    }

    public Rejection(RejectionId id, String reason, String fieldValue, String fieldName, String type) {
        this.id = id;
        this.reason = reason;
        this.fieldValue = fieldValue;
        this.fieldName = fieldName;
        this.type = type;
    }

    // Getters and Setters
    public RejectionId getId() {
        return id;
    }

    public void setId(RejectionId id) {
        this.id = id;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(String fieldValue) {
        this.fieldValue = fieldValue;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}