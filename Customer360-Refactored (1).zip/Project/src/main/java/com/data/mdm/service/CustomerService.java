package com.data.mdm.service;

import com.data.mdm.client.*;
import com.data.mdm.dto.*;
import com.data.mdm.ms.ApiResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
    private final ExternalCustomerClient client;
    private final RequestBuilderService builder;
    private final CustomerPersistenceService persistence;
    private final String username;
    private final String password;

    public CustomerService(ExternalCustomerClient client, RequestBuilderService builder,
            CustomerPersistenceService persistence,
            @Value("${external.customer-api.username:}") String username,
            @Value("${external.customer-api.password:}") String password) {
        this.client = client;
        this.builder = builder;
        this.persistence = persistence;
        this.username = username;
        this.password = password;
    }

    public ServiceResult process(CustomerRequest request) {
        var outbound = new MasterCraftReqest();
        outbound.setUserName(username);
        outbound.setPassWord(password);
        outbound.setRealRequest(builder.buildSourceData(request));
        var auditId = persistence.received(request);
        try {
            // Network I/O is outside the database transaction.
            ApiResponse result = client.callExternalApi(outbound);
            if (result == null || result.getTransactionStatus() == null)
                throw new IllegalStateException("Missing external transaction status");
            if (!"SUCCESS".equalsIgnoreCase(result.getTransactionStatus().getStatus())) {
                persistence.rejected(auditId, request, result);
                return ServiceResult.failed("Customer rejected by external service");
            }
            persistence.completed(auditId, request, result);
            return ServiceResult.success("Customer processed successfully");
        } catch (RuntimeException ex) {
            try { persistence.failed(auditId); }
            catch (RuntimeException auditError) { ex.addSuppressed(auditError); }
            throw ex;
        }
    }
}
