package com.data.mdm.service;

import com.data.mdm.dto.*;
import com.data.mdm.validation.CustomerRequestValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import java.util.concurrent.*;
import java.util.function.Supplier;

@Service
public class CustomerOrchestrationService {
    private static final Logger log = LoggerFactory.getLogger(CustomerOrchestrationService.class);
    private final CustomerService customer;
    private final ProcessAccountService account;
    private final ProcessAncillaryService ancillary;
    private final CustomerRequestValidator validator;
    private final Executor executor;

    public CustomerOrchestrationService(CustomerService customer, ProcessAccountService account,
            ProcessAncillaryService ancillary, CustomerRequestValidator validator,
            @Qualifier("customerExecutor") Executor executor) {
        this.customer = customer;
        this.account = account;
        this.ancillary = ancillary;
        this.validator = validator;
        this.executor = executor;
    }

    public CompletableFuture<FinalApiResponse> process(CustomerRequest request) {
        validator.validate(request);
        var body = request.body();
        var c = submit("customer", body.customer() != null, () -> customer.process(request));
        var a = submit("account", body.account() != null, () -> account.process(request));
        var n = submit("ancillary", body.ancillary() != null, () -> ancillary.process(request));
        return CompletableFuture.allOf(c, a, n).thenApply(ignored ->
                new FinalApiResponse(request.head().trcID(), c.join(), a.join(), n.join()));
    }

    private CompletableFuture<ServiceResult> submit(String name, boolean present, Supplier<ServiceResult> work) {
        if (!present) return CompletableFuture.completedFuture(ServiceResult.skipped());
        try {
            return CompletableFuture.supplyAsync(work, executor).exceptionally(error -> {
                log.warn("{} processing failed ({})", name, error.getClass().getSimpleName());
                return ServiceResult.failed(name + " processing failed");
            });
        } catch (RejectedExecutionException ex) {
            return CompletableFuture.completedFuture(ServiceResult.failed(name + " executor busy; retry later"));
        }
    }
}
