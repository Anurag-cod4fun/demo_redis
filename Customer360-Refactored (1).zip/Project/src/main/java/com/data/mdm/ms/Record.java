package com.data.mdm.ms;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
 
@Data
public class Record {
 
	@JsonProperty("STATUS")
    private String status;
	
    @JsonProperty("SEGMENT")
    private String segment;
    
    @JsonProperty("CREATED_AT")
    private String createdAt;
    
    @JsonProperty("DOB")
    private String dob;
    
    @JsonProperty("PHONE")
    private String phone;
    
    @JsonProperty("CUSTOMERID")
    @com.fasterxml.jackson.annotation.JsonAlias("CUSTOMER_ID")
    private String customerId;
    
    @JsonProperty("GENDER")
    private String gender;
    
    @JsonProperty("LASTNAME")
    @com.fasterxml.jackson.annotation.JsonAlias("LAST_NAME")
    private String lastName;
    
    @JsonProperty("PAN")
    private String pan;
    
    @JsonProperty("EMAIL")
    private String email;
    
    @JsonProperty("RISKRATING")
    @com.fasterxml.jackson.annotation.JsonAlias("RISK_RATING")
    private String riskRating;
    
    @JsonProperty("FIRSTNAME")
    @com.fasterxml.jackson.annotation.JsonAlias("FIRST_NAME")
    private String firstName;
}
 