package com.data.mdm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.data.mdm.entity.AncillaryEntity;



@Repository
public interface AncillaryRepository extends JpaRepository<AncillaryEntity, String> {
	
	

}
