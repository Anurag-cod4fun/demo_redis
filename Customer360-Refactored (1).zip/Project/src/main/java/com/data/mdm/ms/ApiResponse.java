package com.data.mdm.ms;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
 
@Data
public class ApiResponse {
	
	@JsonProperty("Meta")
	private Meta meta;
	
	
	@JsonProperty("Body")
	private Body body;
	
	@JsonProperty("Root")
    private Root root;
	
	@JsonProperty("Transaction Status")
    private TransactionStatus transactionStatus;
 
	@JsonProperty("Processing_Exceptions")
    private ProcessingExceptions processingExceptions;
	
	
	
	
}
 