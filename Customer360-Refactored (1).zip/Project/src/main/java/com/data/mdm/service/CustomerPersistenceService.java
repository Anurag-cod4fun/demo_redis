package com.data.mdm.service;

import com.data.mdm.dto.CustomerRequest;
import com.data.mdm.entity.*;
import com.data.mdm.ms.ApiResponse;
import com.data.mdm.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;

@Service
public class CustomerPersistenceService {
    private final CustomerRepository customers;
    private final ResponseRepository responses;
    private final RejectionRepo rejections;
    private final AuditService audit;

    public CustomerPersistenceService(CustomerRepository customers, ResponseRepository responses,
            RejectionRepo rejections, AuditService audit) {
        this.customers = customers;
        this.responses = responses;
        this.rejections = rejections;
        this.audit = audit;
    }

    @Transactional
    public Long received(CustomerRequest request) {
        var entry = new ApiAudit();
        entry.setTrcId(request.head().trcID());
        entry.setOperationFlag(request.head().operationFlag());
        entry.setCreatedAt(LocalDateTime.now());
        entry.setStatus("RECEIVED");
        return responses.save(entry).getId();
    }

    @Transactional
    public void completed(Long id, CustomerRequest request, ApiResponse result) {
        var c = request.body().customer();
        var record = result.getRoot().getOutput().getRecord();
        var data = customers.findById(new CustomerEntityId(c.getSourcePartyId(), c.getSourceSystemCode()))
                .orElseGet(CustomerEntity::new);
        data.setSourcePartyId(c.getSourcePartyId());
        data.setSourceSystemCode(c.getSourceSystemCode());
        data.setDateCreated(record.getCreatedAt());
        data.setBirthDate(record.getDob());
        data.setMobileNumber(record.getPhone());
        data.setGender(record.getGender());
        data.setLastName(record.getLastName());
        data.setEaddress(record.getEmail());
        data.setPanNbr(record.getPan());
        data.setFirstName(record.getFirstName());
        data.setUcicValue(result.getTransactionStatus().getUcic());
        customers.save(data);
        saveRejection(request, result);
        audit.success(request, "Customer", c.getSourcePartyId(), c.getSourceSystemCode(), null);
        updateAudit(id, "SUCCESS");
    }

    @Transactional
    public void rejected(Long id, CustomerRequest request, ApiResponse result) {
        saveRejection(request, result);
        updateAudit(id, "FAILED");
    }

    @Transactional
    public void failed(Long id) { updateAudit(id, "FAILED"); }

    private void updateAudit(Long id, String status) {
        var entry = responses.findById(id).orElseThrow();
        entry.setStatus(status);
        entry.setResponseJson("{\"status\":\"" + status + "\"}");
    }

    private void saveRejection(CustomerRequest request, ApiResponse result) {
        var exceptions = result.getProcessingExceptions();
        if (exceptions == null || exceptions.getReports() == null || exceptions.getReports().getReport() == null) return;
        var report = exceptions.getReports().getReport();
        var c = request.body().customer();
        var key = new RejectionId();
        key.setSequenceNumber(rejections.getNextSequenceValue());
        key.setSourcePartyId(c.getSourcePartyId());
        key.setSourceSystemCode(c.getSourceSystemCode());
        key.setSourceTimestamp(LocalDateTime.now());
        var rejection = new Rejection();
        rejection.setId(key);
        rejection.setFieldName(report.getFieldName());
        rejection.setFieldValue(report.getFieldValue());
        rejection.setReason(report.getReason());
        rejection.setType(exceptions.getReject() == null || exceptions.getReject().isBlank() ? "WARNING" : exceptions.getReject());
        rejections.save(rejection);
    }
}
