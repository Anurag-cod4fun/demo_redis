package com.data.mdm.ms;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Meta {

	
	@JsonProperty("trcID")
	private String trcID;
	
	@JsonProperty("responseDtTm")
	private String responseDtTm;
	
	@JsonProperty("statusCd")
	private String statusCd;
	
	@JsonProperty("errCd")
	private String errCd;
	
	@JsonProperty("errMsg")
	private String errMsg;
}
