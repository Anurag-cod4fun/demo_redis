package com.data.mdm.client;

public class MasterCraftResponse {

}
