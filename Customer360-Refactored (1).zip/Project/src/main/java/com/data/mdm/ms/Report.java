package com.data.mdm.ms;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Report {
 
	
	@JsonProperty("Field_Value")
    private String fieldValue;
	
	@JsonProperty("Field_Name")
    private String fieldName;
	
	@JsonProperty("Reason")
    private String reason;
    
    
}
 