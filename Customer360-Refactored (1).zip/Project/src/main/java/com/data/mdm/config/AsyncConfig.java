package com.data.mdm.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class AsyncConfig {
    @Bean("customerExecutor")
    public ThreadPoolTaskExecutor customerExecutor(
            @Value("${processing.executor.core-size:8}") int core,
            @Value("${processing.executor.max-size:16}") int max,
            @Value("${processing.executor.queue-capacity:100}") int queue) {
        var executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(core);
        executor.setMaxPoolSize(max);
        executor.setQueueCapacity(queue);
        executor.setThreadNamePrefix("customer-worker-");
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(30);
        return executor;
    }
}
