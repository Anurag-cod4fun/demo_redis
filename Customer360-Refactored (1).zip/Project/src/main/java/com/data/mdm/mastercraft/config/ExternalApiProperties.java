package com.data.mdm.mastercraft.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "external.customer-api")
public record ExternalApiProperties(
        String url,
        String apiKey,
        int connectTimeoutMs,
        int readTimeoutMs
) {}
