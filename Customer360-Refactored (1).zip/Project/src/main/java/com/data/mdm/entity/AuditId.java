package com.data.mdm.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime; // Or Instant / OffsetDateTime depending on your DB column

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuditId implements Serializable {

    @Column(name = "SOURCESYSTEMCODE", nullable = false, length = 50)
    private String sourceSystemCode;

    @Column(name = "SOURCEPARTID", nullable = false, length = 100)
    private String sourcePartyId;

    @Column(name = "SOURCETIMESTAMP", nullable = false)
    private LocalDateTime sourceTimestamp;
}