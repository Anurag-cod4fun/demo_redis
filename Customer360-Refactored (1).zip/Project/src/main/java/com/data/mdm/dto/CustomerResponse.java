package com.data.mdm.dto;

public record CustomerResponse(
        Meta meta,
        ResponseBody body
) {
    public record Meta(
            String trcID,
            String statusCd,
            String channelId,
            String clientApp,
            String responseDtTm,
            String errCd,
            String errMsg
    ) {}

    public record ResponseBody(
            String sourceSysId,
            String custId,
            String ucicId
    ) {}
}
