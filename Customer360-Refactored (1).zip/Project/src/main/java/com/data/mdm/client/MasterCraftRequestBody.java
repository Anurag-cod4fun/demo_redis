package com.data.mdm.client;

public class MasterCraftRequestBody {
	
	String feedSysId;
	String feedCustId;
	String name;
	String birthDate;
	String mobileNum;
	String eaddress;
	String panNbr;
	String custType;
	String busAddress;
	String busPin;
	String curAddress;
	String curPin;
	String mailAddress;
	String mailPin;
	String passportNbr;
	String perAddress;
	String perCity;
	String perPin;
	String drivLicense;
	String infinityId;
	String poBoxDesc;
	String votersId;

	private MasterCraftRequestBody(Builder masterCraftRequestBodyBuilder) {
		
		this.feedSysId = masterCraftRequestBodyBuilder.feedSysId;
		this.feedCustId = masterCraftRequestBodyBuilder.feedCustId;
		this.name = masterCraftRequestBodyBuilder.name;
		this.birthDate = masterCraftRequestBodyBuilder.birthDate;
		this.mobileNum = masterCraftRequestBodyBuilder.mobileNum;
		this.eaddress = masterCraftRequestBodyBuilder.eaddress;
		this.panNbr = masterCraftRequestBodyBuilder.panNbr;
		this.custType = masterCraftRequestBodyBuilder.custType;
		this.busAddress = masterCraftRequestBodyBuilder.busAddress;
		this.busPin = masterCraftRequestBodyBuilder.busPin;
		this.curAddress = masterCraftRequestBodyBuilder.curAddress;
		this.curPin = masterCraftRequestBodyBuilder.curPin;
		this.mailAddress = masterCraftRequestBodyBuilder.mailAddress;
		this.mailPin = masterCraftRequestBodyBuilder.mailPin;
		this.passportNbr = masterCraftRequestBodyBuilder.passportNbr;
		this.perAddress = masterCraftRequestBodyBuilder.perAddress;
		this.perCity = masterCraftRequestBodyBuilder.perCity;
		this.perPin = masterCraftRequestBodyBuilder.perPin;
		this.drivLicense = masterCraftRequestBodyBuilder.drivLicense;
		this.infinityId = masterCraftRequestBodyBuilder.infinityId;
		this.poBoxDesc = masterCraftRequestBodyBuilder.poBoxDesc;
		this.votersId = masterCraftRequestBodyBuilder.votersId;
	}
	public String getFeedSysId() {
		return feedSysId;
	}
	public void setFeedSysId(String feedSysId) {
		this.feedSysId = feedSysId;
	}
	public String getFeedCustId() {
		return feedCustId;
	}
	public void setFeedCustId(String feedCustId) {
		this.feedCustId = feedCustId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	public String getMobileNum() {
		return mobileNum;
	}
	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}
	public String getEaddress() {
		return eaddress;
	}
	public void setEaddress(String eaddress) {
		this.eaddress = eaddress;
	}
	public String getPanNbr() {
		return panNbr;
	}
	public void setPanNbr(String panNbr) {
		this.panNbr = panNbr;
	}
	public String getCustType() {
		return custType;
	}
	public void setCustType(String custType) {
		this.custType = custType;
	}
	public String getBusAddress() {
		return busAddress;
	}
	public void setBusAddress(String busAddress) {
		this.busAddress = busAddress;
	}
	public String getBusPin() {
		return busPin;
	}
	public void setBusPin(String busPin) {
		this.busPin = busPin;
	}
	public String getCurAddress() {
		return curAddress;
	}
	public void setCurAddress(String curAddress) {
		this.curAddress = curAddress;
	}
	public String getCurPin() {
		return curPin;
	}
	public void setCurPin(String curPin) {
		this.curPin = curPin;
	}
	public String getMailAddress() {
		return mailAddress;
	}
	public void setMailAddress(String mailAddress) {
		this.mailAddress = mailAddress;
	}
	public String getMailPin() {
		return mailPin;
	}
	public void setMailPin(String mailPin) {
		this.mailPin = mailPin;
	}
	public String getPassportNbr() {
		return passportNbr;
	}
	public void setPassportNbr(String passportNbr) {
		this.passportNbr = passportNbr;
	}
	public String getPerAddress() {
		return perAddress;
	}
	public void setPerAddress(String perAddress) {
		this.perAddress = perAddress;
	}
	public String getPerCity() {
		return perCity;
	}
	public void setPerCity(String perCity) {
		this.perCity = perCity;
	}
	public String getPerPin() {
		return perPin;
	}
	public void setPerPin(String perPin) {
		this.perPin = perPin;
	}
	public String getDrivLicense() {
		return drivLicense;
	}
	public void setDrivLicense(String drivLicense) {
		this.drivLicense = drivLicense;
	}
	public String getInfinityId() {
		return infinityId;
	}
	public void setInfinityId(String infinityId) {
		this.infinityId = infinityId;
	}
	public String getPoBoxDesc() {
		return poBoxDesc;
	}
	public void setPoBoxDesc(String poBoxDesc) {
		this.poBoxDesc = poBoxDesc;
	}
	public String getVotersId() {
		return votersId;
	}
	public void setVotersId(String votersId) {
		this.votersId = votersId;
	}
	
	public static Builder builder() {
		return new Builder();
	}
	
	public static class Builder {
		String feedSysId;
		String feedCustId;
		String name;
		String birthDate;
		String mobileNum;
		String eaddress;
		String panNbr;
		String custType;
		String busAddress;
		String busPin;
		String curAddress;
		String curPin;
		String mailAddress;
		String mailPin;
		String passportNbr;
		String perAddress;
		String perCity;
		String perPin;
		String drivLicense;
		String infinityId;
		String poBoxDesc;
		String votersId;
		
		
		public Builder feedSysId(String feedSysId) {
			this.feedSysId = feedSysId;
			return this;
		}
		public Builder feedCustId(String feedCustId) {
			this.feedCustId = feedCustId;
			return this;
		}
		public Builder name(String name) {
			this.name = name;
			return this;
		}
		public Builder birthDate(String birthDate) {
			this.birthDate = birthDate;
			return this;
		}
		public Builder mobileNum(String mobileNum) {
			this.mobileNum = mobileNum;
			return this;
		}
		public Builder eaddress(String eaddress) {
			this.eaddress = eaddress;
			return this;
		}
		public Builder panNbr(String panNbr) {
			this.panNbr = panNbr;
			return this;
		}
		public Builder custType(String custType) {
			this.custType = custType;
			return this;
		}
		public Builder busAddress(String busAddress) {
			this.busAddress = busAddress;
			return this;
		}
		public Builder busPin(String busPin) {
			this.busPin = busPin;
			return this;
		}
		public Builder curAddress(String curAddress) {
			this.curAddress = curAddress;
			return this;
		}
		public Builder curPin(String curPin) {
			this.curPin = curPin;
			return this;
		}
		public Builder mailAddress(String mailAddress) {
			this.mailAddress = mailAddress;
			return this;
		}
		public Builder mailPin(String mailPin) {
			this.mailPin = mailPin;
			return this;
		}
		public Builder passportNbr(String passportNbr) {
			this.passportNbr = passportNbr;
			return this;
		}
		public Builder perAddress(String perAddress) {
			this.perAddress = perAddress;
			return this;
		}
		public Builder perCity(String perCity) {
			this.perCity = perCity;
			return this;
		}
		public Builder perPin(String perPin) {
			this.perPin = perPin;
			return this;
		}
		public Builder drivLicense(String drivLicense) {
			this.drivLicense = drivLicense;
			return this;
		}
		public Builder infinityId(String infinityId) {
			this.infinityId = infinityId;
			return this;
		}
		public Builder poBoxDesc(String poBoxDesc) {
			this.poBoxDesc = poBoxDesc;
			return this;
		}
		public Builder votersId(String votersId) {
			this.votersId = votersId;
			return this;
		}
		
		public MasterCraftRequestBody build() {
			return new MasterCraftRequestBody(this);
		}
	}
	
	RequestBuilderService obj1 = new RequestBuilderService();
	
	String realtimeRequest = obj1.buildSourceData(null);
}
