package com.data.mdm.service;

import com.data.mdm.db.service.AccountService;
import com.data.mdm.dto.CustomerRequest;
import com.data.mdm.dto.ServiceResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProcessAccountService {
    private final AccountService persistence;
    private final AuditService audit;
    public ProcessAccountService(AccountService persistence, AuditService audit) {
        this.persistence = persistence;
        this.audit = audit;
    }

    @Transactional
    public ServiceResult process(CustomerRequest request) {
        var data = request.body().account();
        persistence.saveOrUpdate(persistence.mapToAccount(request));
        audit.success(request, "Account", data.getSourcePartyId(), data.getSourceSystemCode(), data.getSourceAccountNumber());
        return ServiceResult.success("Account processed successfully");
    }
}
