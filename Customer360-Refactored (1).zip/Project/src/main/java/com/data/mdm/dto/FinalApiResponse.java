package com.data.mdm.dto;

public record FinalApiResponse(String traceId, ServiceResult customer,
                               ServiceResult account, ServiceResult ancillary) {}
