package com.data.mdm.ms;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
 
@Data
public class Root {
 
	@JsonProperty("Output")
    private Output output;
}
 