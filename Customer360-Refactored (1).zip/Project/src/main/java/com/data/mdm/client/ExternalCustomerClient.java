package com.data.mdm.client;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import com.data.mdm.mastercraft.config.ExternalApiProperties;
import com.data.mdm.ms.ApiResponse;

@Component
public class ExternalCustomerClient {

    private final RestClient restClient;
    private final ExternalApiProperties properties;

    public ExternalCustomerClient(RestClient restClient, ExternalApiProperties properties) {
        this.restClient = restClient;
        this.properties = properties;
    }

    public ApiResponse callExternalApi(MasterCraftReqest request) {
    	ApiResponse response =  restClient.post()
    			.uri(properties.url())
    			.header("api_key", properties.apiKey())
    			.contentType(MediaType.APPLICATION_JSON)
    			.body(request)
    			.retrieve()
    			.body(ApiResponse.class);
        
        return response;
    }
}
