package com.data.mdm.validation;

import com.data.mdm.dto.CustomerRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

@Component
public class CustomerRequestValidator {
    public void validate(CustomerRequest request) {
        var body = request.body();
        if (body == null || (body.customer() == null && body.account() == null && body.ancillary() == null))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "At least one of Customer, Account or Ancillary is required");
        if (body.customer() != null) {
            var c = body.customer();
            required(c.getSourcePartyId(), "Customer.sourcePartyId");
            required(c.getSourceSystemCode(), "Customer.sourceSystemCode");
            required(c.getFirstName(), "Customer.firstName");
            required(c.getMiddleName(), "Customer.middleName");
            required(c.getLastName(), "Customer.lastName");
        }
        if (body.account() != null) {
            var a = body.account();
            required(a.getSourcePartyId(), "Account.sourcePartyId");
            required(a.getSourceSystemCode(), "Account.sourceSystemCode");
            required(a.getSourceAccountNumber(), "Account.sourceAccountNumber");
        }
        if (body.ancillary() != null) {
            var a = body.ancillary();
            required(a.getSourcePartyId(), "Ancillary.sourcePartyId");
            required(a.getSourceSytemCode(), "Ancillary.sourceSystemCode");
        }
    }
    private void required(String value, String field) {
        if (value == null || value.isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, field + " is required");
    }
}
