package com.data.mdm.db.service;

import org.springframework.stereotype.Service;

import com.data.mdm.dto.CustomerRequest;
import com.data.mdm.entity.AncillaryEntity;
import com.data.mdm.repository.AncillaryRepository;
import com.data.mdm.repository.GenericUpdateRepository;

@Service
public class AncillaryService {
 
    private final AncillaryRepository ancillaryRepository;
	
	private final GenericUpdateRepository genericUpdateRepository;
 
    public AncillaryService(AncillaryRepository ancillaryRepository, GenericUpdateRepository genericUpdateRepository) {
        this.ancillaryRepository = ancillaryRepository;
        this.genericUpdateRepository = genericUpdateRepository;
        
    }
    
    public AncillaryEntity  mapToAncillary(CustomerRequest request) {
    	
    var data = request.body().ancillary();
    return AncillaryEntity.builder()
			.sourcePartyId(data.getSourcePartyId())
		    .sourceSystemCode(data.getSourceSytemCode())
		    .ckycId(data.getCkycId())
		    .nationality(data.getNationality())
		    .maritalStatus(data.getMaritalStatus())
		    .fatherName(data.getFatherName())
		    .motherName(data.getMotherName())
		    .spouseName(data.getSpouseName())
		    .disablePerson(data.getDisablePerson())
		    .rmId(data.getRmId())
		    .religion(data.getReligion())
		    .customerSegment(data.getCustomerSegment())
		    .serviceSegment(data.getServiceSegment())
		    .agriIncome(data.getAgriIncome())
		    .nonAgriIncome(data.getNonAgriIncome())
		    .annualIncome(data.getAnnualIncome())
		    .grossAnnualIncome(data.getGrossAnnualIncome())
		    .salary(data.getSalary())
		    .annualSales(data.getAnnualSales())
		    .busiTurnover(data.getBusiTurnover())
		    .basicQualification(data.getBasicQualification())
		    .profQualification(data.getProfQualification())
		    .profession(data.getProfession())
		    .designation(data.getDesignation())
		    .industry(data.getIndustry())
		    .occupationType(data.getOccupationType())
		    .employmentType(data.getEmploymentType())
		    .cusEmployer(data.getCusEmployer())
		    .bsrCode(data.getBsrCode())
		    .fatcaFlag(data.getFatcaFlag())
		    .dateOfBecomingNri(data.getDateOfBecomingNri())
		    .employeeId(data.getEmployeeId())
		    .totYrsOfExperience(data.getTotYrsOfExperience())
		    .noOfEmployees(data.getNoOfEmployees())
		    .legalGuardian(data.getLegalGuardian())
		    .baseAccountNo(data.getBaseAccountNo())
		    .dataClassName(data.getDataClassName())
		    .iviewImageReference(data.getIviewImageReference())
		    .trackingNo(data.getTrackingNo())
		    .countryFlag(data.getCountryFlag())
		    .onekycFlag(data.getOnekycFlag())
		    .rekycFlag(data.getRekycFlag())
		    .videokycCustid(data.getVideokycCustid())
		    .videokycFlag(data.getVideokycFlag())
		    .addrProofColourcode(data.getAddrProofColourcode())
		    .idProofColourcode(data.getIdProofColourcode())
		    .assetAddrProofColourcode(data.getAssetAddrProofColourcode())
		    .assetIdProofColourcode(data.getAssetIdProofColourcode())
		    .dateCreated(data.getDateCreated())
		    .dateLastModified(data.getDateLastModified())
		    .srcCreatedOn(data.getSrcCreatedOn())
		    .srcModifiedOn(data.getSrcModifiedOn())
		    .addressDoclink(data.getAddressDoclink())
		    .idDoclink(data.getIdDoclink())
		    .photoDoclink(data.getPhotoDoclink())
		    .documentLink(data.getDocumentLink())
		    .kycDoclink(data.getKycDoclink())
		    .updatedDocumentLink(data.getUpdatedDocumentLink())
			.build();
}
    
    public void saveOrUpdate(AncillaryEntity ancillaryData) {

        boolean isUpdate = ancillaryData.getSourcePartyId() != null 
                           && ancillaryRepository.existsById(ancillaryData.getSourcePartyId());

        if (isUpdate) {

            genericUpdateRepository.update(ancillaryData, ancillaryData.getSourcePartyId());
        } else {

            ancillaryRepository.save(ancillaryData);
        }
    }
}

