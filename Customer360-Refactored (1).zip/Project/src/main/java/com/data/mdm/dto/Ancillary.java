package com.data.mdm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Ancillary {
	
	public String getTrackingNo() {
		return trackingNo;
	}

	public void setTrackingNo(String trackingNo) {
		this.trackingNo = trackingNo;
	}

	public String getSourcePartyId() {
		return sourcePartyId;
	}

	public String getSourceSytemCode() {
		return sourceSytemCode;
	}

	public String getDateCreated() {
		return DateCreated;
	}

	public String getDateLastModified() {
		return DateLastModified;
	}

	public String getSrcCreatedOn() {
		return SrcCreatedOn;
	}

	public String getSrcModifiedOn() {
		return SrcModifiedOn;
	}

	public void setSourcePartyId(String sourcePartyId) {
		this.sourcePartyId = sourcePartyId;
	}

	public void setSourceSytemCode(String sourceSytemCode) {
		this.sourceSytemCode = sourceSytemCode;
	}

	public void setDateCreated(String dateCreated) {
		DateCreated = dateCreated;
	}

	public void setDateLastModified(String dateLastModified) {
		DateLastModified = dateLastModified;
	}

	public void setSrcCreatedOn(String srcCreatedOn) {
		SrcCreatedOn = srcCreatedOn;
	}

	public void setSrcModifiedOn(String srcModifiedOn) {
		SrcModifiedOn = srcModifiedOn;
	}

	@JsonProperty("SOURCEPARTYID")
	private String sourcePartyId;
	
	@JsonProperty("SOURCESYSTEMCODE")
	private String sourceSytemCode;
	
	@JsonProperty("TrackingNo")
	private String trackingNo;

    private String addrProofColourcode;

    private String addressDoclink;

    private String agriIncome;

    private String annualIncome;

    private String annualSales;

    private String assetAddrProofColourcode;

    private String assetIdProofColourcode;

    private String baseAccountNo;

    private String basicQualification;

    private String bsrCode;

    private String busiTurnover;

    @JsonProperty("CKYCID")
    private String ckycId;

    private String countryFlag;

    private String cusEmployer;

    private String customerSegment;

    private String dataClassName;

    private String dateOfBecomingNri;

    private String designation;

    private String disablePerson;

    private String documentLink;

    private String employeeId;

    private String employmentType;

    private String fatcaFlag;

    @JsonProperty("fatherName")
    private String fatherName;

    private String grossAnnualIncome;

    private String idDoclink;

    private String idProofColourcode;

    private String industry;

    private String iviewImageReference;

    private String kycDoclink;

    private String legalGuardian;

    private String maritalStatus;

    @JsonProperty("motherName")
    private String motherName;

    private String nationality;

    private String noOfEmployees;

    private String nonAgriIncome;

    private String occupationType;

    private String onekycFlag;

    private String photoDoclink;

    private String profQualification;

    private String profession;

    private String rekycFlag;

    private String religion;

    private String rmId;

    private String salary;

    private String serviceSegment;

    private String spouseName;

    private String totYrsOfExperience;

    private String updatedDocumentLink;

    private String videokycCustid;

    private String videokycFlag;
    
    @JsonProperty("DateCreated")
	private String DateCreated;

	@JsonProperty("DateLastModified")
	private String DateLastModified;

	@JsonProperty("SrcCreatedOn")
	private String SrcCreatedOn;

	@JsonProperty("SrcModifiedOn")
	private String SrcModifiedOn;

    public String getAddrProofColourcode() {
        return addrProofColourcode;
    }

    public void setAddrProofColourcode(String addrProofColourcode) {
        this.addrProofColourcode = addrProofColourcode;
    }

    public String getAddressDoclink() {
        return addressDoclink;
    }

    public void setAddressDoclink(String addressDoclink) {
        this.addressDoclink = addressDoclink;
    }

    public String getAgriIncome() {
        return agriIncome;
    }

    public void setAgriIncome(String agriIncome) {
        this.agriIncome = agriIncome;
    }

    public String getAnnualIncome() {
        return annualIncome;
    }

    public void setAnnualIncome(String annualIncome) {
        this.annualIncome = annualIncome;
    }

    public String getAnnualSales() {
        return annualSales;
    }

    public void setAnnualSales(String annualSales) {
        this.annualSales = annualSales;
    }

    public String getAssetAddrProofColourcode() {
        return assetAddrProofColourcode;
    }

    public void setAssetAddrProofColourcode(String assetAddrProofColourcode) {
        this.assetAddrProofColourcode = assetAddrProofColourcode;
    }

    public String getAssetIdProofColourcode() {
        return assetIdProofColourcode;
    }

    public void setAssetIdProofColourcode(String assetIdProofColourcode) {
        this.assetIdProofColourcode = assetIdProofColourcode;
    }

    public String getBaseAccountNo() {
        return baseAccountNo;
    }

    public void setBaseAccountNo(String baseAccountNo) {
        this.baseAccountNo = baseAccountNo;
    }

    public String getBasicQualification() {
        return basicQualification;
    }

    public void setBasicQualification(String basicQualification) {
        this.basicQualification = basicQualification;
    }

    public String getBsrCode() {
        return bsrCode;
    }

    public void setBsrCode(String bsrCode) {
        this.bsrCode = bsrCode;
    }

    public String getBusiTurnover() {
        return busiTurnover;
    }

    public void setBusiTurnover(String busiTurnover) {
        this.busiTurnover = busiTurnover;
    }

    public String getCkycId() {
        return ckycId;
    }

    public void setCkycId(String ckycId) {
        this.ckycId = ckycId;
    }

    public String getCountryFlag() {
        return countryFlag;
    }

    public void setCountryFlag(String countryFlag) {
        this.countryFlag = countryFlag;
    }

    public String getCusEmployer() {
        return cusEmployer;
    }

    public void setCusEmployer(String cusEmployer) {
        this.cusEmployer = cusEmployer;
    }

    public String getCustomerSegment() {
        return customerSegment;
    }

    public void setCustomerSegment(String customerSegment) {
        this.customerSegment = customerSegment;
    }

    public String getDataClassName() {
        return dataClassName;
    }

    public void setDataClassName(String dataClassName) {
        this.dataClassName = dataClassName;
    }

    public String getDateOfBecomingNri() {
        return dateOfBecomingNri;
    }

    public void setDateOfBecomingNri(String dateOfBecomingNri) {
        this.dateOfBecomingNri = dateOfBecomingNri;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDisablePerson() {
        return disablePerson;
    }

    public void setDisablePerson(String disablePerson) {
        this.disablePerson = disablePerson;
    }

    public String getDocumentLink() {
        return documentLink;
    }

    public void setDocumentLink(String documentLink) {
        this.documentLink = documentLink;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmploymentType() {
        return employmentType;
    }

    public void setEmploymentType(String employmentType) {
        this.employmentType = employmentType;
    }

    public String getFatcaFlag() {
        return fatcaFlag;
    }

    public void setFatcaFlag(String fatcaFlag) {
        this.fatcaFlag = fatcaFlag;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getGrossAnnualIncome() {
        return grossAnnualIncome;
    }

    public void setGrossAnnualIncome(String grossAnnualIncome) {
        this.grossAnnualIncome = grossAnnualIncome;
    }

    public String getIdDoclink() {
        return idDoclink;
    }

    public void setIdDoclink(String idDoclink) {
        this.idDoclink = idDoclink;
    }

    public String getIdProofColourcode() {
        return idProofColourcode;
    }

    public void setIdProofColourcode(String idProofColourcode) {
        this.idProofColourcode = idProofColourcode;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public String getIviewImageReference() {
        return iviewImageReference;
    }

    public void setIviewImageReference(String iviewImageReference) {
        this.iviewImageReference = iviewImageReference;
    }

    public String getKycDoclink() {
        return kycDoclink;
    }

    public void setKycDoclink(String kycDoclink) {
        this.kycDoclink = kycDoclink;
    }

    public String getLegalGuardian() {
        return legalGuardian;
    }

    public void setLegalGuardian(String legalGuardian) {
        this.legalGuardian = legalGuardian;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getMotherName() {
        return motherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getNoOfEmployees() {
        return noOfEmployees;
    }

    public void setNoOfEmployees(String noOfEmployees) {
        this.noOfEmployees = noOfEmployees;
    }

    public String getNonAgriIncome() {
        return nonAgriIncome;
    }

    public void setNonAgriIncome(String nonAgriIncome) {
        this.nonAgriIncome = nonAgriIncome;
    }

    public String getOccupationType() {
        return occupationType;
    }

    public void setOccupationType(String occupationType) {
        this.occupationType = occupationType;
    }

    public String getOnekycFlag() {
        return onekycFlag;
    }

    public void setOnekycFlag(String onekycFlag) {
        this.onekycFlag = onekycFlag;
    }

    public String getPhotoDoclink() {
        return photoDoclink;
    }

    public void setPhotoDoclink(String photoDoclink) {
        this.photoDoclink = photoDoclink;
    }

    public String getProfQualification() {
        return profQualification;
    }

    public void setProfQualification(String profQualification) {
        this.profQualification = profQualification;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getRekycFlag() {
        return rekycFlag;
    }

    public void setRekycFlag(String rekycFlag) {
        this.rekycFlag = rekycFlag;
    }

    public String getReligion() {
        return religion;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public String getRmId() {
        return rmId;
    }

    public void setRmId(String rmId) {
        this.rmId = rmId;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getServiceSegment() {
        return serviceSegment;
    }

    public void setServiceSegment(String serviceSegment) {
        this.serviceSegment = serviceSegment;
    }

    public String getSpouseName() {
        return spouseName;
    }

    public void setSpouseName(String spouseName) {
        this.spouseName = spouseName;
    }

    public String getTotYrsOfExperience() {
        return totYrsOfExperience;
    }

    public void setTotYrsOfExperience(String totYrsOfExperience) {
        this.totYrsOfExperience = totYrsOfExperience;
    }

    public String getUpdatedDocumentLink() {
        return updatedDocumentLink;
    }

    public void setUpdatedDocumentLink(String updatedDocumentLink) {
        this.updatedDocumentLink = updatedDocumentLink;
    }

    public String getVideokycCustid() {
        return videokycCustid;
    }

    public void setVideokycCustid(String videokycCustid) {
        this.videokycCustid = videokycCustid;
    }

    public String getVideokycFlag() {
        return videokycFlag;
    }

    public void setVideokycFlag(String videokycFlag) {
        this.videokycFlag = videokycFlag;
    }

}
