//package com.data.mdm.client;
//
//import com.fasterxml.jackson.annotation.JsonProperty;
//
//public class Root {
//
//	@JsonProperty("Output")
//	Object output;
//
//	@JsonProperty("TransactionStatus")
//	TransactionalStatus transactionalStatus;
//
//	public Object getOutput() {
//		return output;
//	}
//
//	public void setOutput(Object output) {
//		this.output = output;
//	}
//
//	public TransactionalStatus getTransactionalStatus() {
//		return transactionalStatus;
//	}
//
//	public void setTransactionalStatus(TransactionalStatus transactionalStatus) {
//		this.transactionalStatus = transactionalStatus;
//	}
//
//	public Root(Object output, TransactionalStatus transactionalStatus) {
//		super();
//		this.output = output;
//		this.transactionalStatus = transactionalStatus;
//	}
//
//	public Root() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//	
//
//}
