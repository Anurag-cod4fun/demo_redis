package com.data.mdm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.data.mdm.entity.ApiAudit;

public interface ResponseRepository extends JpaRepository<ApiAudit, Long> {
}
