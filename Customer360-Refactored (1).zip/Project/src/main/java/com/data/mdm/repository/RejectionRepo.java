package com.data.mdm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.data.mdm.entity.Rejection;
import com.data.mdm.entity.RejectionId;


@Repository
public interface RejectionRepo extends JpaRepository<Rejection, RejectionId> {
	
	@Query(value = "SELECT REJECTION_SEQ.NEXTVAL FROM DUAL",nativeQuery = true) 
	 Long getNextSequenceValue();
	
}

