package com.data.mdm.entity;

import java.io.Serializable;
import java.util.Objects;

public class CustomerEntityId implements Serializable {
    private String sourcePartyId;
    private String sourceSystemCode;

    public CustomerEntityId() {}

    public CustomerEntityId(String sourcePartyId, String sourceSystemCode) {
        this.sourcePartyId = sourcePartyId;
        this.sourceSystemCode = sourceSystemCode;
    }

    // Generate equals() and hashCode() using both fields
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CustomerEntityId that = (CustomerEntityId) o;
        return Objects.equals(sourcePartyId, that.sourcePartyId) &&
               Objects.equals(sourceSystemCode, that.sourceSystemCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sourcePartyId, sourceSystemCode);
    }
}