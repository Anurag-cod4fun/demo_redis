package com.data.mdm.client;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MasterCraftReqest {

	@JsonProperty("userName")
	String userName;

	@JsonProperty("passWord")
	String passWord;

	@JsonProperty("realRequest")
	String realRequest;

	public String getUserName() {
		return userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public String getRealRequest() {
		return realRequest;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	public void setRealRequest(String realRequest) {
		this.realRequest = realRequest;
	}
}
