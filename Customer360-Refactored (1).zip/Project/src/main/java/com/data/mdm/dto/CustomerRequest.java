package com.data.mdm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record CustomerRequest(@NotNull @Valid Head head, @NotNull @Valid  RequestBody body) {

    public record Head( @NotBlank String requestDtTm, @NotBlank String trcID, @NotBlank String operationFlag) {}

    public record RequestBody(@JsonProperty("Account") Account account, @JsonProperty("Customer")Customer customer, @JsonProperty("Ancillary")Ancillary ancillary) {}
}
