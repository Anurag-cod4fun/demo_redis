package com.data.mdm.entity;
public enum RejectionType {
    REJECT,
    EXCEPTION
}