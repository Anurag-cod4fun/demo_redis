package com.data.mdm.ms;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
 
@Data
public class ProcessingExceptions {
 
	@JsonProperty("Reject")
    private String reject;
	
	@JsonProperty("Reports")
    private Reports reports;
}
 