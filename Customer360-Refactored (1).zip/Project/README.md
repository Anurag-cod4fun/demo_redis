# Customer API – refactored POC

Java 21 / Spring Boot 3.5.5. Existing endpoint: POST /api/v1/customer/ucic.

## Run locally

Requires JDK 21 and Maven 3.9+. The default `local` profile uses an in-memory H2 database in Oracle compatibility mode and enables the existing external API stub (`POST /getResp`).

```sh
mvn clean test
mvn spring-boot:run
curl -H 'Content-Type: application/json' -d @examples/request.json http://localhost:8080/api/v1/customer/ucic
```

Expected shape (illustrative, not an executed test):

```json
{"traceId":"demo-001","customer":{"status":"SUCCESS","message":"Customer processed successfully"},"account":{"status":"SUCCESS","message":"Account processed successfully"},"ancillary":{"status":"SUCCESS","message":"Ancillary processed successfully"}}
```

Remove any section to exercise SKIPPED. A valid request returns HTTP 200 with three independent results, including partial failures. Invalid requests return HTTP 400 before any writes. FAILED does not imply other sections were rolled back. An MVC timeout or disconnect does not cancel already-running writes; use reconciliation/idempotency before retries.

## Oracle deployment

Set `SPRING_PROFILES_ACTIVE=oracle`, `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`, `CUSTOMER_API_URL`, `CUSTOMER_API_KEY`, `CUSTOMER_API_USERNAME`, `CUSTOMER_API_PASSWORD`. Existing tables and REJECTION_SEQ must exist. No schema changes are applied in Oracle mode. The original private Maven dependency Data:Customer360DB was not included in the archive and no source imports use it; it was replaced with Boot-managed ojdbc11. Verify whether your environment needs that artifact for non-source resources or runtime integration.

## Structure and flow

- controller: HTTP request/response and exception mapping.
- validation: validates each supplied section independently.
- service: orchestration, individual business operations, shared audit and customer persistence.
- db/service: account and ancillary mapping and patch persistence.
- repository/entity: JPA database access and existing table mappings.
- client, ms, mastercraft/config: external request/response protocol and HTTP client.
- config: bounded executor configuration; stub: local-only external endpoint.
- docs/legacy: inactive TMS prototype, old customer mapper and commented entities retained for reference, not compiled.

Orchestration submits three typed futures on a dedicated executor. Each task maps its own outcome to SUCCESS/FAILED, or SKIPPED when absent. allOf waits for completion, then joins completed futures and returns the aggregate. Spring MVC handles the returned future asynchronously; no servlet thread waits for all three tasks. Each service owns its transaction. The customer network call runs outside the database transaction; received, completed and failed audits use separate transactions. Account and ancillary writes plus their success audit are atomic per service. Generic patch skips null and empty strings and supports single IDs only. Account uses sourceAccountNumber as its actual ID; customer uses its composite ID.

## Design decisions / limitations

- Success classification for external customer response assumes Status=Success (case insensitive). A report with blank reject type is stored as WARNING; confirm the allowed values with your schema/business owners.
- Audit bodies are intentionally minimized to avoid storing raw customer PII; confirm regulatory audit requirements before rollout. Rejection records still retain field values as in the source design.
- The audit table's existing composite key includes a timestamp; check Oracle timestamp precision for parallel writes sharing a party/system. A unique audit event ID is recommended if schema changes are allowed.
- The account/ancillary existence-check + patch/insert pattern is retained; simultaneous requests targeting the same missing row may race. Consider database-native upsert or appropriate locking once Oracle requirements are confirmed.
- Executor defaults 8 core/16 max, queue 100, DB pool 10. Tune with load tests. Rejected tasks return FAILED. HTTP client connect/read timeouts are wired; MVC timeout is not a cancellation guarantee.
- Original Oracle credentials removed; rotate exposed credentials if real. Local stub is not enabled in Oracle profile.
- Two orchestration unit tests supplied; Maven was unavailable in the editing environment, so compilation and runtime tests have not been executed. Run the commands above before deploying.
